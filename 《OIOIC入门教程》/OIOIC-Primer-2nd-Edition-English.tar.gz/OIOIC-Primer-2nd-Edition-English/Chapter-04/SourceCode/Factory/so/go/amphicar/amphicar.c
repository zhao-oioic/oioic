/**
 *
 * �� �� ����amphicar.c
 *
 * ��    ����
 *
 * �� �� �ߣ�
 *
 * �������ڣ�
 *
 * ��    ע��
 *
 *
 * * ά����ʷ *
 *
 *   <����>                <�޸���>
 *   <�޸�����...>
 *
 **/

#include <stdlib.h>
#include "../vehicle/vehicle.h"
#include "../car/car.h"
#include "../ship/ship.h"
#include "amphicar.h"


VOID  TOG_amphicar(OBJECT* pObj);


/*=====================+ OICC label +====================*/

/*<oicc>*/
/*<ibn> car, ship </ibn>*/
/*<crt>*/
FRESULT  CRT_amphicar(OBJID* pOID, BYTKTY IQCty, BYTKTY OQCty, SI32 NumCR, OBJECT** ppObj, BYTE* pExotic)
{
	extern  VOID  InitAIBofND(OBJECT* pND, MLDSN* pMsn, NUMIB nib);
	extern  VOID  InitABNofND(OBJECT* pND, MLDSN* pMsn, NUMBN nbn);
	extern  VOID  TOG_car(OBJECT* pObj);
	extern  VOID  TOG_vehicle(OBJECT* pObj);
	extern  VOID  TOG_OIOIC(OBJECT* pObj);
	extern  VOID  TOG_ship(OBJECT* pObj);


	UI32   ux_ND = 5; 	/* ND������*/
	UI32   ux_BN = 9; 	/* ��ND��BN����֮�͡�*/
	UI32   ux_IB = 5; 	/* ��ND��IBN����֮�͡�*/
	UI32   ux_CS = NumCR * 12; 	/* ��ND������CS����֮�͡�*/
	UI32   ux_EM = sizeof(EM_CAR) + sizeof(EM_VEHICLE) + sizeof(EM_OIOIC)
		 + sizeof(EM_SHIP); 	/* ��ND��EM�ߴ�֮�͡�*/

	UI32  sum = ux_ND * sizeof(OBJECT) 	/* for AND. */
		 + ux_BN * sizeof(OBJECT*) 	/* for "ppo_ABN". */
		 + ux_IB * sizeof(OBJECT*) 	/* for "ppo_AIB". */
		 + ux_CS * sizeof(VR) + ux_EM; 	/* for "pvr_ACS" and "pEM". */


	BYTE*  pIC = NULL;

	if(NULL == pExotic)
	{
		*ppObj = NULL;
		pIC = (BYTE*)calloc(sum, 1);
	}else
	{
		pIC = pExotic;
	}


	if( pIC != NULL )
	{
		OBJECT*  pND;
		MLDSN    ArrMsn[4];
		BYTE*    p = pIC + sizeof(OBJECT) * ux_ND;


		/***  ȷ��AND��Ԫ��  ***/

		/** amphicar **/
		pND = (OBJECT*)pIC;
		TOG_amphicar(pND);
		pND->MSN = MSN_AMPHICAR;
		pND->OID = (*pOID)++;
		pND->po_AND = (OBJECT*)pIC;
		pND->NND = ux_ND;

		/** car **/
		TOG_car(++pND);
		pND->MSN = MSN_CAR;
		pND->OID = (*pOID)++;
		pND->po_AND = (OBJECT*)pIC;
		pND->NND = ux_ND;

		/** vehicle **/
		TOG_vehicle(++pND);
		pND->MSN = MSN_VEHICLE;
		pND->OID = (*pOID)++;
		pND->po_AND = (OBJECT*)pIC;
		pND->NND = ux_ND;

		/** OIOIC **/
		TOG_OIOIC(++pND);
		pND->MSN = MSN_OIOIC;
		pND->OID = (*pOID)++;
		pND->po_AND = (OBJECT*)pIC;
		pND->NND = ux_ND;

		/** ship **/
		TOG_ship(++pND);
		pND->MSN = MSN_SHIP;
		pND->OID = (*pOID)++;
		pND->po_AND = (OBJECT*)pIC;
		pND->NND = ux_ND;


		/***  ��ʼ����ND  ***/

		/** amphicar **/
		pND = (OBJECT*)pIC;

		/* - AIB - */
		pND->ppo_AIB = (OBJECT**)p;
		ArrMsn[0] = MSN_CAR;
		ArrMsn[1] = MSN_SHIP;
		InitAIBofND(pND, ArrMsn, 2);
		p += sizeof(OBJECT*) * 2;

		/* - ABN - */
		pND->ppo_ABN = (OBJECT**)p;
		ArrMsn[0] = MSN_CAR;
		ArrMsn[1] = MSN_VEHICLE;
		ArrMsn[2] = MSN_OIOIC;
		ArrMsn[3] = MSN_SHIP;
		InitABNofND(pND, ArrMsn, 4);
		p += sizeof(OBJECT*) * 4;

		/* - ACS - */
		pND->pvr_ACS = (VR*)p;
		pND->NCS = NumCR * 1;
		p += sizeof(VR) * pND->NCS;

		/** car **/
		++pND;

		/* - AIB - */
		pND->ppo_AIB = (OBJECT**)p;
		ArrMsn[0] = MSN_VEHICLE;
		InitAIBofND(pND, ArrMsn, 1);
		p += sizeof(OBJECT*) * 1;

		/* - ABN - */
		pND->ppo_ABN = (OBJECT**)p;
		ArrMsn[0] = MSN_VEHICLE;
		ArrMsn[1] = MSN_OIOIC;
		InitABNofND(pND, ArrMsn, 2);
		p += sizeof(OBJECT*) * 2;

		/* - ACS - */
		pND->pvr_ACS = (VR*)p;
		pND->NCS = NumCR * 2;
		p += sizeof(VR) * pND->NCS;

		/* - EM - */
		pND->pEM = (EM*)p;
		p += sizeof(EM_CAR);

		/** vehicle **/
		++pND;

		/* - AIB - */
		pND->ppo_AIB = (OBJECT**)p;
		ArrMsn[0] = MSN_OIOIC;
		InitAIBofND(pND, ArrMsn, 1);
		p += sizeof(OBJECT*) * 1;

		/* - ABN - */
		pND->ppo_ABN = (OBJECT**)p;
		ArrMsn[0] = MSN_OIOIC;
		InitABNofND(pND, ArrMsn, 1);
		p += sizeof(OBJECT*) * 1;

		/* - ACS - */
		pND->pvr_ACS = (VR*)p;
		pND->NCS = NumCR * 3;
		p += sizeof(VR) * pND->NCS;

		/* - EM - */
		pND->pEM = (EM*)p;
		p += sizeof(EM_VEHICLE);

		/** OIOIC **/
		++pND;

		/* - ACS - */
		pND->pvr_ACS = (VR*)p;
		pND->NCS = NumCR * 4;
		p += sizeof(VR) * pND->NCS;

		/* - EM - */
		pND->pEM = (EM*)p;
		if( IQCty > 0 )
		{
			/* - IQ - */
			((EM_OIOIC*)(pND->pEM))->IQ.Dtrm = (BYTE*)calloc(IQCty, 1);
			if( NULL == ((EM_OIOIC*)(pND->pEM))->IQ.Dtrm)
			{
				/* ����IQ������ʧ�ܣ�*/
				if(NULL == pExotic)
					free(pIC);
				return FR_N;
			}
			((EM_OIOIC*)(pND->pEM))->IQ.Front = ((EM_OIOIC*)(pND->pEM))->IQ.Rear = ((EM_OIOIC*)(pND->pEM))->IQ.Dtrm - 1;
			((EM_OIOIC*)(pND->pEM))->IQ.Cty = IQCty;
			((EM_OIOIC*)(pND->pEM))->IQ.Qty = ((EM_OIOIC*)(pND->pEM))->IQ.Lost = 0;
		}

		if( OQCty > 0 )
 		{
			/* - OQ - */
			((EM_OIOIC*)(pND->pEM))->OQ.Dtrm = (BYTE*)calloc(OQCty, 1);
			if(NULL == ((EM_OIOIC*)(pND->pEM))->OQ.Dtrm)
			{
				/* ����OQ������ʧ�ܣ�*/
				if( ((EM_OIOIC*)(pND->pEM))->IQ.Dtrm != NULL )
					free(((EM_OIOIC*)(pND->pEM))->IQ.Dtrm);
				if(NULL == pExotic)
					free(pIC);
				return FR_N;
			}
			((EM_OIOIC*)(pND->pEM))->OQ.Front = ((EM_OIOIC*)(pND->pEM))->OQ.Rear = ((EM_OIOIC*)(pND->pEM))->OQ.Dtrm - 1;
			((EM_OIOIC*)(pND->pEM))->OQ.Cty = OQCty;
			((EM_OIOIC*)(pND->pEM))->OQ.Qty = ((EM_OIOIC*)(pND->pEM))->OQ.Lost = 0;
		}
		p += sizeof(EM_OIOIC);

		/** ship **/
		++pND;

		/* - AIB - */
		pND->ppo_AIB = (OBJECT**)p;
		ArrMsn[0] = MSN_VEHICLE;
		InitAIBofND(pND, ArrMsn, 1);
		p += sizeof(OBJECT*) * 1;

		/* - ABN - */
		pND->ppo_ABN = (OBJECT**)p;
		ArrMsn[0] = MSN_VEHICLE;
		ArrMsn[1] = MSN_OIOIC;
		InitABNofND(pND, ArrMsn, 2);
		p += sizeof(OBJECT*) * 2;

		/* - ACS - */
		pND->pvr_ACS = (VR*)p;
		pND->NCS = NumCR * 2;
		p += sizeof(VR) * pND->NCS;

		/* - EM - */
		pND->pEM = (EM*)p;
		p += sizeof(EM_SHIP);
	}else
	{
		return FR_N;
	}


	if(NULL == pExotic)
		*ppObj = (OBJECT*)pIC;


	return FR_P;
}
/*</crt>*/
/*</oicc>*/

/*=====================+ Interface +=====================*/

/**
*
* ���ƣ�amphicar_Open
*/
static IRESULT  amphicar_Open(OBJECT* This, const VR* pCaller)
{
	EM_VEHICLE*		pvem = GetEMofBN(This, MSN_VEHICLE); 
	EM_CAR*			pcem = GetEMofBN(This, MSN_CAR); 
	EM_SHIP*		psem = GetEMofBN(This, MSN_SHIP); 

	OBS_OBJECT_OPEN_;

	/* ��������ɽӿ��Լ�������*/


	pvem->weight = 4.06f;
	pcem->max_load = 10.93f;
	pcem->max_velocity = 215.00f;
	psem->max_load = 12.5f;
	psem->max_velocity = 138.00f;


	return IR_P;
}

/**
*
* ���ƣ�amphicar_Input
*/
static IRESULT  amphicar_Input(OBJECT* This, BYTE* IStrm, BYTKTY Qty, const VR* pCaller)
{

	/* ... */


	/* ��������ɽӿ��Լ�������*/

	SBO_OBJECT_INPUT;
}

/**
*
* ���ƣ�amphicar_Output
*/
static IRESULT  amphicar_Output(OBJECT* This, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller)
{

	/* ... */


	/* ��������ɽӿ��Լ�������*/

	SBO_OBJECT_OUTPUT;
}

/**
*
* ���ƣ�amphicar_IOput
*/
static IRESULT  amphicar_IOput(OBJECT* This, BYTE* IStrm, BYTKTY Qty, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller)
{

	/* ... */


	/* ��������ɽӿ��Լ�������*/

	SBO_OBJECT_IOPUT;
}

/**
*
* ���ƣ�amphicar_Interact0
*/
static IRESULT  amphicar_Interact0(OBJECT* This, ACTION Act, const VR* pCaller)
{

	/* ... */


	/* ��������ɽӿ��Լ�������*/

	SBO_OBJECT_INTERACT0;
}

/**
*
* ���ƣ�amphicar_Interact1
*/
static IRESULT  amphicar_Interact1(OBJECT* This, ACTION Act, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller)
{
	EM_CAR*			pcem = GetEMofBN(This, MSN_CAR); 
	EM_SHIP*		psem = GetEMofBN(This, MSN_SHIP); 

	switch(Act)
	{
	case GET_TMAXLOAD: /* ��ȡ½�ϣ�terrestrial�������������*/
		assert(Cty >= sizeof(SR32));
		*(SR32*)OStrm = pcem->max_load; 
		*pQty = sizeof(SR32); 
		return IR_P;
	case GET_TMAXVELOCITY: /* ��ȡ½������ٶȡ�*/
		assert(Cty >= sizeof(SR32));
		*(SR32*)OStrm = pcem->max_velocity; 
		*pQty = sizeof(SR32); 
		return IR_P;
	case GET_AMAXLOAD: /* ��ȡˮ�ϣ�aquatic�������������*/
		assert(Cty >= sizeof(SR32));
		*(SR32*)OStrm = psem->max_load; 
		*pQty = sizeof(SR32); 
		return IR_P;
	case GET_AMAXVELOCITY: /* ��ȡˮ������ٶȡ�*/
		assert(Cty >= sizeof(SR32));
		*(SR32*)OStrm = psem->max_velocity; 
		*pQty = sizeof(SR32); 
		return IR_P;
	default:
		break;
	}


	/* ��������ɽӿ��Լ�������*/

	SBO_OBJECT_INTERACT1;
}

/**
*
* ���ƣ�amphicar_Interact2
*/
static IRESULT  amphicar_Interact2(OBJECT* This, ACTION  Act, BYTE* IStrm, BYTKTY Qty, const VR* pCaller)
{

	/* ... */


	/* ��������ɽӿ��Լ�������*/

	SBO_OBJECT_INTERACT2;
}

/**
*
* ���ƣ�amphicar_Interact3
*/
static IRESULT  amphicar_Interact3(OBJECT* This, ACTION Act, BYTE* IStrm, BYTKTY Qty, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller)
{

	/* ... */


	/* ��������ɽӿ��Լ�������*/

	SBO_OBJECT_INTERACT3;
}

/**
*
* ���ƣ�amphicar_Close
*/
static IRESULT  amphicar_Close(OBJECT* This, const VR* pCaller)
{
	OBS_OBJECT_CLOSE_;

	/* ��������ɽӿ��Լ�������*/

	if(0 == This->RefCnt)
		return IR_P_RCZERO;

	return IR_P;
}

/*========================+ TOG +========================*/

/**
*
* ���ƣ�TOG_amphicar
*/
VOID  TOG_amphicar(OBJECT* pObj)
{
	pObj->Open = amphicar_Open;
	pObj->Input = amphicar_Input;
	pObj->Output = amphicar_Output;
	pObj->IOput = amphicar_IOput;
	pObj->Interact0 = amphicar_Interact0;
	pObj->Interact1 = amphicar_Interact1;
	pObj->Interact2 = amphicar_Interact2;
	pObj->Interact3 = amphicar_Interact3;
	pObj->Close = amphicar_Close;
}

/*=======================+ IRF(s) +======================*/
/* ... */

/*====================+ Function(s) +====================*/
/* ... */


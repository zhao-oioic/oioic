# Microsoft Developer Studio Project File - Name="Factory" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Console Application" 0x0103

CFG=Factory - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "Factory.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "Factory.mak" CFG="Factory - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "Factory - Win32 Release" (based on "Win32 (x86) Console Application")
!MESSAGE "Factory - Win32 Debug" (based on "Win32 (x86) Console Application")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
RSC=rc.exe

!IF  "$(CFG)" == "Factory - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /c
# ADD CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /c
# ADD BASE RSC /l 0x804 /d "NDEBUG"
# ADD RSC /l 0x804 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /machine:I386
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /machine:I386

!ELSEIF  "$(CFG)" == "Factory - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /GZ /c
# ADD CPP /nologo /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /GZ /c
# ADD BASE RSC /l 0x804 /d "_DEBUG"
# ADD RSC /l 0x804 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /debug /machine:I386 /pdbtype:sept
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /debug /machine:I386 /pdbtype:sept

!ENDIF 

# Begin Target

# Name "Factory - Win32 Release"
# Name "Factory - Win32 Debug"
# Begin Group "oioic"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\oioic\oioic.c
# End Source File
# Begin Source File

SOURCE=.\oioic\oioic.h
# End Source File
# End Group
# Begin Group "se"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\se\se.c
# End Source File
# Begin Source File

SOURCE=.\se\se.h
# End Source File
# End Group
# Begin Group "so"

# PROP Default_Filter ""
# Begin Group "ao"

# PROP Default_Filter ""
# Begin Group "Main"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\so\ao\Main\Main.c
# End Source File
# Begin Source File

SOURCE=.\so\ao\Main\Main.h
# End Source File
# End Group
# Begin Source File

SOURCE=.\so\ao\ao.c
# End Source File
# Begin Source File

SOURCE=.\so\ao\ao.h
# End Source File
# End Group
# Begin Group "go"

# PROP Default_Filter ""
# Begin Group "car"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\so\go\car\car.c
# End Source File
# Begin Source File

SOURCE=.\so\go\car\car.h
# End Source File
# End Group
# Begin Group "vehicle"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\so\go\vehicle\vehicle.c
# End Source File
# Begin Source File

SOURCE=.\so\go\vehicle\vehicle.h
# End Source File
# End Group
# Begin Source File

SOURCE=.\so\go\go.c
# End Source File
# Begin Source File

SOURCE=.\so\go\go.h
# End Source File
# End Group
# Begin Source File

SOURCE=.\so\so.c
# End Source File
# Begin Source File

SOURCE=.\so\so.h
# End Source File
# End Group
# Begin Source File

SOURCE=.\Factory.c
# End Source File
# Begin Source File

SOURCE=.\Factory.h
# End Source File
# Begin Source File

SOURCE=.\ho.c
# End Source File
# Begin Source File

SOURCE=.\ho.h
# End Source File
# End Target
# End Project

/**
 *
 * Name: oioic.c
 *
 * Description: the .c file of OIOIC��
 *
 * Creator: ��ƽ�� (a Chinese)  <pervise.zhao@gmail.com>
 *
 * Date: 20050310
 *
 * Version: 1.0.6
 *
 * Copyright(C)2005-2009 ��ƽ�� (a Chinese)��All Rights Reserved.������
 *
 * Remarks:
 *
 *
 * * HISTORY *
 *
 *   < Date >             < Who >
 *   < Content... >
 *
 **/

#include <stdlib.h>
#include <string.h> 
#include "oioic.h"


/*=====================+ Interface +=====================*/

/**
*
* Name: OIOIC_Open
* Desc: the "Open" interface.
* Para: pCaller --- [IN] caller.
*/
static IRESULT  OIOIC_Open(OBJECT* This, const VR* pCaller)
{
	This->RefCnt++; 
	return IR_P;
}

/**
*
* Name: OIOIC_Input
* Desc: the "Input" interface.
* Para: IStrm --- [IN] inputted stream;
*       Qty --- [IN] the quantity of inputted byte;
*       pCaller --- [IN] caller. 
*/
static IRESULT  OIOIC_Input(OBJECT* This, BYTE* IStrm, BYTKTY Qty, const VR* pCaller)
{
	return IR_O_SBOOIX;
}

/**
*
* Name: OIOIC_Output
* Desc: the "Output" interface.
* Para: OStrm --- [OUT] saves the outputted stream;
*       Cty --- [IN] the OStrm's capacity;
*       pQty --- [OUT] saves the actual quantity of outputted byte;
*       pCaller --- [IN] caller.
*/
static IRESULT  OIOIC_Output(OBJECT* This, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller)
{	
   	return IR_O_SBOOIX;
}

/**
*
* Name: OIOIC_IOput
* Desc: the "IOput" interface.
* Para: IStrm --- [IN] inputted stream;
*       Qty --- [IN] the quantity of inputted byte;
*       OStrm --- [OUT] saves the outputted stream;
*       Cty --- [IN] the OStrm's capacity;
*       pQty --- [OUT] saves the actual quantity of outputted byte;
*       pCaller --- [IN] caller.
*/
static IRESULT  OIOIC_IOput(OBJECT* This, BYTE* IStrm, BYTKTY Qty, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller)
{
	return IR_O_SBOOIX;
}

/**
*
* Name: OIOIC_Interact0
* Desc: the "Interact0" interface.
* Para: Act --- [IN] interaction.
*       pCaller --- [IN] caller.
*/
static IRESULT  OIOIC_Interact0(OBJECT* This, ACTION Act, const VR* pCaller)
{
	EM_OIOIC*  pem = (EM_OIOIC*)This->pEM;

	switch( Act )
	{
		case ASK_SHARED: /* Is the object shared? */
			if(pem->mds & MOD_SHARED) 
				return IR_N;
			return IR_P;
		case SET_SHARED: /* Set to be shared. */
			pem->mds &= ~MOD_SHARED;
			return IR_P;
		case SET_UNSHARED: /* Set to be unshared. */
			pem->mds |= MOD_SHARED;
			return IR_P;
		case SET_BLOCKI: /* Set to be blocked input. */
			pem->mds &= ~MOD_BLOCKI;
			return IR_P;
		case SET_UNBLOCKI: /* Set to be non-blocked input. */
			pem->mds |= MOD_BLOCKI;
			return IR_P;
		case SET_BLOCKO: /* Set to be blocked output. */
			pem->mds &= ~MOD_BLOCKO;
			return IR_P;
		case SET_UNBLOCKO: /* Set to be non-blocked output. */
			pem->mds |= MOD_BLOCKO;
			return IR_P;
		case CMD_RESET: /* Reset. */
			pem->IQ.Front = pem->IQ.Rear = pem->IQ.Dtrm - 1;
			pem->IQ.Qty = pem->IQ.Lost = 0;
			pem->OQ.Front = pem->OQ.Rear = pem->OQ.Dtrm - 1;
			pem->OQ.Qty = pem->OQ.Lost = 0;
			return IR_P;
		default:
			break;					
	}

	return IR_O_SBOOIX;			
}

/**
*
* Name: OIOIC_Interact1
* Desc: the "Interact1" interface.
* Para: Act --- [IN] interaction;
*       OStrm --- [OUT] saves the outputted stream;
*       Cty --- [IN] the OStrm's capacity;
*       pQty --- [OUT] saves the actual quantity of outputted byte;
*       pCaller --- [IN] caller.
*/
static IRESULT  OIOIC_Interact1(OBJECT* This, ACTION Act, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller)
{
	EM_OIOIC*   pem = (EM_OIOIC*)(This->pEM);

	switch( Act )
	{
		case GET_IQCTY: /* Get the IQ's capacity. */
			assert( Cty >= sizeof(BYTKTY) );
			*((BYTKTY*)OStrm) = pem->IQ.Cty;
			*pQty = sizeof(BYTKTY); 
			return IR_P;
		case GET_OQCTY: /* Get the OQ's capacity. */
			assert( Cty >= sizeof(BYTKTY) );
			*((BYTKTY*)OStrm) = pem->OQ.Cty;
			*pQty = sizeof(BYTKTY); 
			return IR_P;
		default:
			break;						
	}
	
	return IR_O_SBOOIX;
}

/**
*
* Name: OIOIC_Interact2
* Desc: the "Interact2" interface.
* Para: Act --- [IN] interaction;
*       IStrm --- [IN] the inputted stream;
*       Qty --- [IN] the quantity of inputted byte;
*       pCaller --- [IN] caller.
*/
static IRESULT  OIOIC_Interact2(OBJECT* This, ACTION  Act, BYTE* IStrm, BYTKTY Qty, const VR* pCaller)
{
	EM_OIOIC*   pem = (EM_OIOIC*)(This->pEM);

	switch( Act )
	{
		case SET_IQCTY: /* Set the IQ's capacity. */
			assert( sizeof(BYTKTY) == Qty );
			if(pem->IQ.Dtrm != NULL)
				free(pem->IQ.Dtrm); 
			pem->IQ.Dtrm = (BYTE*)calloc(*((BYTKTY*)IStrm), 1);
			if( pem->IQ.Dtrm != NULL )
			{
				pem->IQ.Front = pem->IQ.Rear = pem->IQ.Dtrm - 1;
				pem->IQ.Cty = *((BYTKTY*)IStrm);
				pem->IQ.Qty = pem->IQ.Lost = 0;
				return IR_P;
			}else 
			{ 
				return IR_N;
			}
		case SET_OQCTY: /* Set the OQ's capacity. */
			assert( sizeof(BYTKTY) == Qty );
			if(pem->OQ.Dtrm != NULL)
				free(pem->OQ.Dtrm); 
			pem->OQ.Dtrm = (BYTE*)calloc(*((BYTKTY*)IStrm), 1);
			if( pem->OQ.Dtrm != NULL ) 
			{
				pem->OQ.Front = pem->OQ.Rear = pem->OQ.Dtrm - 1;
				pem->OQ.Cty = *((BYTKTY*)IStrm);
				pem->OQ.Qty = pem->OQ.Lost = 0;
				return IR_P; 
			}else 
			{ 
				return IR_N; 
			}
		default:
			break;						
	}
	
	return IR_O_SBOOIX;
}

/**
*
* Name: OIOIC_Interact3
* Desc: the "Interact3" interface.
* Para: Act --- [IN] interaction;
*       IStrm --- [IN] the inputted stream;
*       Qty --- [IN] the quantity of inputted byte;
*       OStrm --- [OUT] saves the outputted stream;
*       Cty --- [IN] the OStrm's capacity;
*       pQty --- [OUT] saves the actual quantity of outputted byte;
*       pCaller --- [IN] caller.
*/
static IRESULT  OIOIC_Interact3(OBJECT* This, ACTION Act, BYTE* IStrm, BYTKTY Qty, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller)
{	
	return IR_O_SBOOIX;
}

/**
*
* Name: OIOIC_Close
* Desc: the "Close" interface.
* Para: pCaller --- [IN] caller.
*/
static IRESULT  OIOIC_Close(OBJECT* This, const VR* pCaller)
{
	This->RefCnt--; 
	return IR_P;
}

/*========================+ TOG +========================*/

/**
*
* Name: TOG_OIOIC
*/
VOID  TOG_OIOIC(OBJECT* pObj)
{
	pObj->Open = OIOIC_Open;
	pObj->Input = OIOIC_Input;
	pObj->Output = OIOIC_Output;
	pObj->IOput = OIOIC_IOput;
	pObj->Interact0 = OIOIC_Interact0;
	pObj->Interact1 = OIOIC_Interact1;
	pObj->Interact2 = OIOIC_Interact2;
	pObj->Interact3 = OIOIC_Interact3;
	pObj->Close = OIOIC_Close;
}

/*=============+ InitAIBofND & InitABNofND +=============*/

/* NOTE: The "InitAIBofND" and "InitABNofND" are called only by CRT function. */

/**
*
* Name: InitAIBofND
* Desc: Initializes the AIB of ND.
* Para: pND --- [IN] points the ND;
*       pMsn --- [IN] the array of IB's MSN;
*       nib --- [IN] the number of element in the "pMsn" array, that is the number of IB.
* Remarks: 1. Called only by CRT function.
*          2. The order of elements in the "pMsn" array determines the order of IB's visiting.
*/
VOID  InitAIBofND(OBJECT* pND, MLDSN* pMsn, NUMIB nib)
{
	NUMND   i;
	NUMIB   j;
	
	pND->NIB = nib;
	
	while(nib)
	{
		j = pND->NIB-nib;
		for(i=1; i<pND->NND; i++)
		{
			if( *(pMsn+j) == (pND->po_AND+i)->MSN )
			{
				*(pND->ppo_AIB+j) = pND->po_AND+i;
				break;
			}
		}
		nib--;
	}
}	

/**
*
* Name: InitABNofND
* Desc: Initializes the ABN of ND.
* Para: pND --- [IN] points the ND;
*       pMsn --- [IN] the array of BN's MSN;
*       nbn --- [IN] the number of element in the "pMsn" array, that is the number of BN.
* Remarks: Called only by CRT function.
*/
VOID  InitABNofND(OBJECT* pND, MLDSN* pMsn, NUMBN nbn)
{
	NUMND  i;
	NUMBN  j;
	
	pND->NBN = nbn;
	
	while(nbn)
	{
		j = pND->NBN-nbn;
		for(i=1; i<pND->NND; i++)
		{
			if( *(pMsn+j) == (pND->po_AND+i)->MSN )
			{
				*(pND->ppo_ABN+j) = pND->po_AND+i;
				break;
			}
		}
		nbn--;
	}
}

/*=============+ CallerCome & CallerLeave +==============*/

/* NOTE: Not to call the "CallerCome" and "CallerLeave" in outside. */

/**
*
* Name: CallerCome
* Desc: A caller comes, records the visiting. 
* Para: pND --- [IN] points the ND;
*       pCaller --- [IN] caller.
* Remarks: Not to call it in outside.
*/
FRESULT CallerCome(OBJECT* pND, const VR* pCaller)
{    
	NUMCS   i;
	VR*   pVR; 
	
	/* Is there the VR? */
	for(i=0; i<pND->NCS; i++)
	{
		pVR = pND->pvr_ACS+i;
		if((pVR->cr == pCaller->cr) && (pVR->mr == pCaller->mr))
			return FR_N_HASVR; /* the VR already exists. */
	}

	/* Record the VR. */
	for(i=0; i<pND->NCS; i++)
	{
		pVR = pND->pvr_ACS+i;
		if( 0 == pVR->cr )
		{
			*pVR = *pCaller;
			return FR_P;
		}
	}
		
	return FR_N;  
}

/**
*
* Name: CallerLeave
* Desc: A caller leaves, clean out the visiting record.
* Para: pND --- [IN] points the ND;
*       pCaller --- [IN] caller.
* Remarks: Not to call it in outside.
*/
FRESULT CallerLeave(OBJECT* pND, const VR* pCaller)
{
	NUMBN  i;
	NUMCS  j;
	VR*  pVR;
	
	/* firstly for the BN(s) of ND. */
	for(i=0; i<pND->NBN; i++)
	{
		for(j=0; j<(*(pND->ppo_ABN+i))->NCS; j++)
		{
			pVR = (*(pND->ppo_ABN+i))->pvr_ACS+j;
		  	if((pVR->cr == pCaller->cr) && (pVR->mr == pCaller->mr))
				pVR->cr = pVR->mr = 0;
		}
	}
	
	/* then for the ND itself. */
	for(j=0; j<pND->NCS; j++)
	{
		pVR = pND->pvr_ACS+j;
		if((pVR->cr == pCaller->cr) && (pVR->mr == pCaller->mr))
			pVR->cr = pVR->mr = 0;
	} 

	return FR_P;
}

/*==================+ Enqueue & Dequeue +================*/

/**
*
* Name: Enqueue
* Desc: Put byte(s) into a specified queue.
* Para: IData --- [IN] the data to enqueue;
*       Qty --- [IN] the quantity of byte to enqueue.
*/
FRESULT  Enqueue(QUEUE* pq, BYTE* IData, BYTKTY Qty)
{
    BYTE*     newRear;  /* the position of "pq-> Rear" after successfully enqueue. */
	BYTKTY   ctyFree, qtyEnq;
	
	assert( pq != NULL );
	assert( IData != NULL );
	
	ctyFree = pq->Cty - pq->Qty;
	qtyEnq = (ctyFree > Qty) ? Qty : ctyFree;

	
	if( 0 == qtyEnq )
	{
		if( Qty > 0 )
		{
			pq->Lost = Qty;  /* lost "Qty" byte(s)! */
			return FR_N_LOST;
		}

		return FR_O_VAINLY;
	}

		
	newRear = pq->Dtrm + (pq->Rear + qtyEnq - pq->Dtrm ) % pq->Cty; 
	if(newRear > pq->Rear) /* If successfully enqueue, the "pq->Rear" doesn't have to cycle? */
	{
		memcpy(pq->Rear+1, IData, qtyEnq);
	}else /* If successfully enqueue, the "pq->Rear" has to cycle. */
	{	
		BYTKTY   qty1, qty2;
		qty1 = pq->Dtrm + pq->Cty - pq->Rear - 1;
		if(qty1 > 0)
			memcpy(pq->Rear+1, IData, qty1);
		qty2 = qtyEnq - qty1;
		memcpy(pq->Dtrm, IData + qty1, qty2);
	}

	pq->Rear = newRear;
	pq->Qty += qtyEnq;

	if(pq->Dtrm-1 == pq->Front)
		pq->Front = pq->Dtrm;

	if(ctyFree < Qty)
	{
	   pq->Lost = Qty - ctyFree;  /* lost "Qty - ctyFree" byte(s)! */
	   return FR_N_LOST;
	}
	
	return FR_P;
}

/**
*
* Name: Dequeue
* Desc: Get byte(s) from a specified queue.
* Para: OData --- [OUT] saves the data dequeued;
*       Cty --- [IN] the OData's capacity;
*       pQty --- [OUT] saves the actual quantity of byte dequeued.
*/
FRESULT  Dequeue(QUEUE* pq, BYTE* OData, BYTKTY Cty, BYTKTY* pQty)
{
	BYTE*    newFront;  /* the position of "pq->Front" after successfully dequeue. */
    BYTKTY   qtyDeq;  /* the actual quantity of byte dequeued. */

	assert( pq != NULL );
	assert( OData != NULL );
	assert( Cty != 0 );
	assert( pQty != NULL );
	
	*pQty = 0; 
	
	if( pq->Qty != 0 )
	{
		qtyDeq = (Cty > pq->Qty) ? pq->Qty : Cty;

		newFront = pq->Dtrm + (pq->Front + qtyDeq - pq->Dtrm) % pq->Cty;
		if(newFront > pq->Front) /* After dequeue, the "pq->Front" doesn't have to cycle? */
		{
			memcpy(OData, pq->Front, qtyDeq);
		}else /* After dequeue, the "pq->Front" has to cycle? */
		{
			BYTKTY   qty1, qty2;
			qty1 = pq->Dtrm + pq->Cty - pq->Front;
			qty2 = qtyDeq - qty1;
			memcpy(OData, pq->Front, qty1);
			memcpy(OData + qty1, pq->Dtrm, qty2);
		}

		pq->Qty -= qtyDeq;

		if(0 == pq->Qty)
			pq->Front = pq->Rear = pq->Dtrm -1;
		else
			pq->Front = newFront;

	}else
	{
	   return FR_O_VAINLY;
	}

	*pQty = qtyDeq;
	
	if(pq->Lost > 0)
	{
	   pq->Lost = 0;
	   return  FR_N_LOST;
	}	

	return FR_P;
} 

/*=================+ GetBN & GetEMofBN +=================*/

/**
*
* Name: GetBN
* Desc: Get the specified BN of a ND.
* Para: pND --- [IN] points the ND;
*      msn --- [IN] BN's mold.
* Return: the pointer of BN.
*/
OBJECT*  GetBN(OBJECT* pND, MLDSN msn)
{
	NUMBN   i;
	
	assert( pND != NULL );

	for(i=0; i<pND->NBN; i++)
	{
		if( msn == (*(pND->ppo_ABN+i))->MSN )
			return  *(pND->ppo_ABN+i);
	}
	
	return NULL;  /* û�����BN��*/
}

/**
*
* Name: GetEMofBN
* Desc: Get the EM of a specified BN of a ND.
* Para: pND --- [IN] points the ND;
*       msn --- [IN] BN's mold.
* Return: the pointer of EM.
*/
EM*  GetEMofBN(OBJECT* pND, MLDSN msn)
{
	NUMBN   i;
	
	assert( pND != NULL );

	for(i=0; i<pND->NBN; i++)
	{
		if( msn == (*(pND->ppo_ABN+i))->MSN )
			return  (*(pND->ppo_ABN+i))->pEM;
	}
	
	return NULL; 
}	

/*===================+ GetIQ & GetOQ +===================*/

/**
*
* Name: GetIQ
* Desc: Get a node's IQ.
* Para: pND --- [IN] points the ND.
* Return: the pointer of IQ.
*/
QUEUE*  GetIQ(OBJECT* pND)
{
	NUMBN   i;
	
	assert( pND != NULL );

	for(i=0; i<pND->NBN; i++)
	{
		if( MSN_OIOIC == (*(pND->ppo_ABN+i))->MSN )
			return  &((EM_OIOIC*)((*(pND->ppo_ABN+i))->pEM))->IQ;
	}
	
	return NULL; 
}

/**
*
* Name: GetOQ
* Desc: Get Get a node's OQ.
* Para: pND --- [IN] points the ND.
* Return: the pointer of OQ.
*/
QUEUE*  GetOQ(OBJECT* pND)
{
	NUMBN   i;
	
	assert( pND != NULL );

	for(i=0; i<pND->NBN; i++)
	{
		if( MSN_OIOIC == (*(pND->ppo_ABN+i))->MSN )
			return  &((EM_OIOIC*)((*(pND->ppo_ABN+i))->pEM))->OQ;
	}
	
	return NULL; 
}


/*==================+  ������VO����  +===================*/

/* NODE: the function of inlined VO functions and that of non-inlined are identical. */


#if INLINE_VOFUNCTION == 0

/**
*
* Name: VO_Open
* Desc: the VO function of the "Open" interface.
* Para: pObject --- [IN] points the object;
*       pCaller --- [IN] points the VR.
*/    	             
IRESULT  VO_Open(OBJECT* pObject, const VR* pCaller)
{
	extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller);
	extern  FRESULT CallerLeave(OBJECT* pND, const VR* pCaller);

	IRESULT  ir = IR_O;

	assert( pObject != NULL );
	assert( pCaller->cr != 0 );
	assert( pCaller->mr != 0 );
	
	if( FR_P == CallerCome(pObject, pCaller) )
	{
		ir = pObject->Open(pObject, pCaller);
		CallerLeave(pObject, pCaller);
	}else { ir = IR_N; }
	
	return ir;
}
       
/**
*
* Name: VO_Input
* Desc: the VO function of the "Input" interface.
* Para: pObject --- [IN] points the object; 
*      IStrm --- [IN] inputted stream;
*      Qty --- [IN] the quantity of inputted byte;
*      pCaller --- [IN] points the VR.
*/          
IRESULT  VO_Input(OBJECT* pObject, BYTE* IStrm, BYTKTY Qty, const VR* pCaller)
{
	extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller);
	extern  FRESULT CallerLeave(OBJECT* pND, const VR* pCaller);

	IRESULT  ir = IR_O;

	assert( pObject != NULL );
	assert( IStrm != NULL );
	assert( Qty > 0 );
	assert( pCaller->cr != 0 );
	assert( pCaller->mr !=0 );

	if( FR_P == CallerCome(pObject, pCaller) ) 
	{ 
		ir = pObject->Input(pObject, IStrm, Qty, pCaller); 
		CallerLeave(pObject, pCaller); 
	}else { ir = IR_N; }
	
	return ir;
}

/**
*
* Name: VO_Output
* Desc: the VO function of the "Output" interface.
* Para: pObject --- [IN] points the object;  
*      OStrm --- [OUT] saves the outputted stream;
*      Cty --- [IN] the OStrm's capacity;
*      pQty --- [OUT] saves the actual quantity of byte outputted;
*      pCaller --- [IN] points the VR.
*/      
IRESULT  VO_Output(OBJECT* pObject, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller) 
{
	extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller);
	extern  FRESULT CallerLeave(OBJECT* pND, const VR* pCaller);

	IRESULT  ir = IR_O;

	assert( pObject != NULL );
	assert( OStrm != NULL );
	assert( Cty > 0 );
	assert( pQty != NULL );
	assert( pCaller->cr != 0 );
	assert( pCaller->mr != 0 );

	*pQty = 0;

	if( FR_P == CallerCome(pObject, pCaller) ) 
	{ 
		ir = pObject->Output(pObject, OStrm, Cty, pQty, pCaller); 
		CallerLeave(pObject, pCaller); 
	}else { ir = IR_N; }
	
	return ir;
}

/**
*
* Name: VO_IOput
* Desc: the VO function of the "IOput" interface.
* Para: pObject --- [IN] points the object;  
*       IStrm --- [IN] inputted stream;
*       Qty --- [IN] the quantity of inputted byte;
*       OStrm --- [OUT] saves the outputted stream;
*       Cty --- [IN] the OStrm's capacity;
*       pQty --- [OUT] saves the actual quantity of byte outputted;
*       pCaller --- [IN] points the VR.
*/  
IRESULT  VO_IOput(OBJECT* pObject, BYTE* IStrm, BYTKTY Qty, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller)
{
	extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller);
	extern  FRESULT CallerLeave(OBJECT* pND, const VR* pCaller);
	
	IRESULT  ir = IR_O;

	assert( pObject != NULL );
	assert( IStrm != NULL );
	assert( Qty > 0 );
	assert( OStrm != NULL );
	assert( Cty > 0 );
	assert( pQty != NULL );
	assert( pCaller->cr != 0 );
	assert( pCaller->mr != 0 );
	
	*pQty = 0;

	if( FR_P == CallerCome(pObject, pCaller) ) 
	{ 
		ir = pObject->IOput(pObject, IStrm, Qty, OStrm, Cty, pQty, pCaller); 
		CallerLeave(pObject, pCaller); 
	}else { ir = IR_N; }
	
	return ir;
}

/**
*
* Name: VO_Interact0
* Desc: the VO function of the "Interact0" interface.
* Para: pObject --- [IN] points the object; 
*       Act --- [IN] interaction;
*       pCaller --- [IN] points the VR.
*/	       
IRESULT  VO_Interact0(OBJECT* pObject, ACTION Act, const VR* pCaller) 
{
	extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller);
	extern  FRESULT CallerLeave(OBJECT* pND, const VR* pCaller);

	IRESULT  ir = IR_O;

	assert( pObject != NULL );
	assert( (MSKAC & Act) == AC0 );
	assert( pCaller->cr != 0 );
	assert( pCaller->mr != 0 );
	
	if( FR_P == CallerCome(pObject, pCaller) )
	{
		ir = pObject->Interact0(pObject, Act, pCaller);
		CallerLeave(pObject, pCaller);
	}else { ir = IR_N; }
	
	return ir;
}

/**
*
* Name: VO_Interact1
* Desc: the VO function of the "Interact1" interface.
* Para: pObject --- [IN] points the object; 
*       Act --- [IN] interaction;
*       OStrm --- [OUT] saves the outputted stream;
*       Cty --- [IN] the OStrm's capacity;
*       pQty --- [OUT] saves the actual quantity of byte outputted;
*       pCaller --- [IN] points the VR.
*/       
IRESULT  VO_Interact1(OBJECT* pObject, ACTION Act, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller) 
{
	extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller);
	extern  FRESULT CallerLeave(OBJECT* pND, const VR* pCaller);

	IRESULT  ir = IR_O;

	assert( pObject != NULL );
	assert( (MSKAC & Act) == AC1 );
	assert( OStrm != NULL );
	assert( Cty > 0 );
	assert( pQty != NULL );
	assert( pCaller->cr != 0 );
	assert( pCaller->mr != 0 );

	*pQty = 0;

	if( FR_P == CallerCome(pObject, pCaller) ) 
	{ 
		ir = pObject->Interact1(pObject, Act, OStrm, Cty, pQty, pCaller); 
		CallerLeave(pObject, pCaller); 
	}else { ir = IR_N; }
	
	return ir;
}

/**
*
* Name: VO_Interact2
* Desc: the VO function of the "Interact2" interface.
* Para: pObject --- [IN] points the object; 
*       Act --- [IN] interaction;
*       IStrm --- [IN] inputted stream;
*       Qty --- [IN] the quantity of inputted byte;
*       pCaller --- [IN] points the VR.
*/       
IRESULT  VO_Interact2(OBJECT* pObject, ACTION Act, BYTE* IStrm, BYTKTY Qty, const VR* pCaller)  
{
	extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller);
	extern  FRESULT CallerLeave(OBJECT* pND, const VR* pCaller);

	IRESULT  ir = IR_O;
	
	assert( pObject != NULL );
	assert( (MSKAC & Act) == AC2 );
	assert( IStrm != NULL );
	assert( Qty > 0 );
	assert( pCaller->cr != 0 );
	assert( pCaller->mr != 0 );

	if( FR_P == CallerCome(pObject, pCaller) ) 
	{ 
		ir = pObject->Interact2(pObject, Act, IStrm, Qty, pCaller); 
		CallerLeave(pObject, pCaller); 
	}else { ir = IR_N; }
	
	return ir;
}

/**
*
* Name: VO_Interact3
* Desc: the VO function of the "Interact3" interface.
* Para: pObject --- [IN] points the object; 
*       Act --- [IN] interaction;
*       IStrm --- [IN] inputted stream;
*       Qty --- [IN] the quantity of inputted byte;
*       OStrm --- [OUT] saves the outputted stream;
*       Cty --- [IN] the OStrm's capacity;
*       pQty --- [OUT] saves the actual quantity of byte outputted;
*       pCaller --- [IN] points the VR.
*/       
IRESULT  VO_Interact3(OBJECT* pObject, ACTION Act, BYTE* IStrm, BYTKTY Qty, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller)  
{
	extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller);
	extern  FRESULT CallerLeave(OBJECT* pND, const VR* pCaller);

	IRESULT  ir = IR_O;

	assert( pObject != NULL );
	assert( (MSKAC & Act) == AC3 );
	assert( IStrm != NULL );
	assert( Qty > 0 );
	assert( OStrm != NULL );
	assert( Cty > 0 );
	assert( pQty != NULL );
	assert( pCaller->cr != 0 );
	assert( pCaller->mr != 0 );

	*pQty = 0;

	if( FR_P == CallerCome(pObject, pCaller) ) 
	{ 
		ir = pObject->Interact3(pObject, Act, IStrm, Qty, OStrm, Cty, pQty, pCaller); 
		CallerLeave(pObject, pCaller); 
	}else { ir = IR_N; }
	
	return ir;
}

/**
*
* Name: VO_Close
* Desc: the VO function of the "Close" interface.
* Para: pObject --- [IN] points the object;  
*       pCaller --- [IN] points the VR.
*/       
IRESULT  VO_Close(OBJECT* pObject, const VR* pCaller) 
{
	extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller);
	extern  FRESULT CallerLeave(OBJECT* pND, const VR* pCaller);

	IRESULT  ir = IR_O;
	
	assert( pObject != NULL );
	assert( pCaller->cr != 0 );
	assert( pCaller->mr != 0 );

	if( FR_P == CallerCome(pObject, pCaller) ) 
	{ 
		ir = pObject->Close(pObject, pCaller); 
		CallerLeave(pObject, pCaller); 
	}else { ir = IR_N; }
	
	return ir;
}

#endif

/**
 *
 * Name: oioic.h
 *
 * Description: the .h file of OIOIC��
 *
 * Creator: ��ƽ�� (a Chinese)  <pervise.zhao@gmail.com>
 *
 * Date: 20050310
 *
 * Version: 1.0.6
 *
 * Copyright(C)2005-2009 ��ƽ�� (a Chinese)��All Rights Reserved.������
 *
 * Remarks:
 *
 *
 * * HISTORY *
 *
 *   < Date >             < Who >
 *   < Content... >
 *
 **/

#ifndef __OIOIC_H__
#define __OIOIC_H__
      
/* #define  NDEBUG */
#include <assert.h>


/*
*
* Name: INLINE_VOFUNCTION
* Desc: The switch to inline VO functions. 0 - not inline, 1 - inline, others - reserved.
* Remarks: If it is 1, whether the VO functions is inlined really, depends on whether the 
*         following "_INLINE_" macro is effective.
*/
#define     INLINE_VOFUNCTION          0

/*
*
* Name: _INLINE_
* Desc: Since the inline keyword is not same in different compilers, redefine it.
* Remarks: It must be an effectual definition, otherwise, even if the compiling is passed, 
*          the inline is noneffective, the compiler will not inline them.
*/
#define      _INLINE_		__inline
     

/*
*
* Desc: The masks of OS, HO, SO.
* Remarks: The OID is expressed by 64 bits (See the following data type definition of OBJID).
*          The high 16 bits identify OS, the middle 32 bits identify HO, the low 16 bits identify SO.
*/
#define   MSKOS		  0xFFFF000000000000
#define   MSKHO		  0x0000FFFFFFFF0000
#define   MSKSO		  0x000000000000FFFF


/*
*
* the OID of each OS.
*/
#define		OID_OICOS            0x0001000000000000     /* Oicos's OID. */
#define		OID_UNIX             0x0002000000000000     /* Unix's OID. */
#define		OID_LINUX            0x0003000000000000     /* Linux's OID. */
#define		OID_WINDOWS          0x0004000000000000     /* Windows's OID. */


/*
*
* Name: OID_OS
* Desc: OS's OID.
*/
#define		OID_OS            OID_WINDOWS


/*
*
* Define the first level data types.
*/
typedef  char                      SI8;  
typedef  unsigned char             UI8;  
typedef  short                     SI16;  
typedef  unsigned short            UI16; 
typedef  int                       SI32; 
typedef  unsigned int              UI32; 

#if OID_OS == OID_OICOS
#elif OID_OS == OID_UNIX
#elif OID_OS == OID_LINUX
typedef  long long                 SI64;
typedef  unsigned long long        UI64;
#elif OID_OS == OID_WINDOWS
typedef  __int64                   SI64;
typedef  unsigned __int64          UI64;
#else
#error the OID of OS is undefined.
#endif

typedef  float			           SR32;
/* typedef  unsigned float            UR32;  */
typedef  double                    SR64;
/* typedef  unsigned double           UR64; */
typedef  void                      VOID; 


/*
*
* Define the second level data types.
*/
typedef  UI8      BYTE;    /* byte type. */
typedef  UI16     ACTION;  /* interaction type. */
typedef  UI32     BYTKTY;  /* by BYTe, c(K)apaciTY and q(K)uantiTY's type. */
typedef  UI32     BITKTY;  /* by BIT, c(K)apaciTY and q(K)uantiTY's type. */

typedef  UI16     MLDSN;  /* MSN type. */
typedef  UI64     OBJID;  /* OID type. */
typedef  UI32     REFCNT; /* object's REFerence CouNT type. */
typedef  UI32     MODES;  /* MODES type. */

typedef  UI16     NUMCS;  /* the NUMber of CS type. */
typedef  UI16     NUMND;  /* the NUMber of ND type. */
typedef  UI16     NUMIB;  /* the NUMber of IB type. */
typedef  UI16     NUMBN;  /* the NUMber of BN type. */

typedef  SI8      BOOL;  /* Boolean type, the data type can only have two values: TRUE or FALSE (See the following definition of TRUE and FALSE). */

typedef  SI32     IRESULT;  /* the executive result data type of an object's interface, must be signed. */
typedef  SI32     FRESULT;  /* the executive result data type of a function, must be signed. */


/*
*
* the size of byte (the number of bit)
*/
#define    BYTESIZE         8


/*
*
* Desc: MSN
* Remarks: Starting from 1, the following is the MSN's definition template.
*       #define   MSN_XXX1    (MSN_ + 0)  /-* xxx1's MSN. HO *-/
*       #define   MSN_XXX2    (MSN_ + 1)  /-* xxx2's MSN. AO *-/
*       #define   MSN_XXX3    (MSN_ + 2)  /-* xxx3's MSN. .. *-/
*       #define   MSN_XXX4    (MSN_ + 3)  /-* xxx4's MSN. GO *-/
*       #define   MSN_XXX5    (MSN_ + 4)  /-* xxx5's MSN. .. *-/
*       ...     ...     ...     ...     ...     ...   
*       #define   MSN_XXXn    (MSN_ + n-1)  /-* xxxn's MSN. ... *-/
*/
#define    MSN_OIOIC         1				   /* OIOIC's MSN. */
#define    MSN_              (MSN_OIOIC + 1)   /* the starting-point of other MSNs. */

/*
*
* Desc: Define generic modes.
* Remarks: Can define sizeof(MODES)*BYTESIZE modes. As follows,
*
*    #define   MOD_                     1
*    #define   MOD_XXX0             ( MOD_ << 0 )     /-* BIT0��1��xxx��0��xxx��*-/
*    #define   MOD_XXX1             ( MOD_ << 1 )     /-* BIT1��1��xxx��0��xxx��*-/
*    #define   MOD_XXX2             ( MOD_ << 2 )     /-* BIT2��1��xxx��0��xxx��*-/
*       ...     ...     ...     ...     ...     ...    
*    #define   MOD_XXXn            ( MOD_ << (sizeof(MODES)*BYTESIZE-1) )   /-* BITn�� 1��xxx�� 0��xxx��*-/
*/
#define   MOD_                  1
#define   MOD_SHARED            ( MOD_ << 0 )     /* BIT0. 0: Shared; 1: Unshared. */
#define   MOD_BLOCKI            ( MOD_ << 1 )     /* BIT1. 0: Blocked input; 1: Non-blocked input. Applies only to the Input and IOput interfaces. */
#define   MOD_BLOCKO            ( MOD_ << 2 )     /* BIT2. 0: Blocked output; 1: Non-blocked output. Applies only to the the Output and IOput interfaces. */


/*
*
* Desc: Define the executive results of object's interfaces. 
* Remarks: === Template ===
*
*       ...     ...     ...     ...     ...     ...    
*       ...     ...     ...     ...     ...     ...    
*       #define     IR_N_PVT_YYY_            (IR_N_PVT_XXX_ - x)  /-* the starting-point of X2's private N result. *-/
*       #define     IR_N_XXX            (IR_N_PVT_XXX_ - x + 1) 
*       ...     ...     ...     ...     ...     ... 
*       #define     IR_N_XXX            (IR_N_PVT_XXX_ -1) 
*       #define     IR_N_XXX            (IR_N_PVT_XXX_ -0) 
*       /-** Private N results of X1 object model: ^ **-/
*
*       #define     IR_N_PVT_XXX_            (IR_N_PVT_ - x)  /-* the starting-point of X1's private N result. *-/
*       #define     IR_N_XXX            (IR_N_PVT_ - x + 1) 
*       ...     ...     ...     ...     ...     ...  
*       #define     IR_N_XXX            (IR_N_PVT_ -1) 
*       #define     IR_N_XXX            (IR_N_PVT_ -0) 
*       /-** 
*       ** Non-exclusive N results for one object model: ^ 
*       **-/ 
*
*       ...     ...     ...     ...     ...     ...    
*       ...     ...     ...     ...     ...     ...    
*       #define     IR_O_PVTN_YYY_           (IR_O_PVTN_XXX_ - x)  /-* the starting-point of X2's private negative O result. *-/
*       #define     IR_O_XXX            (IR_O_PVTN_XXX_ - x + 1) 
*       ...     ...     ...     ...     ...     ... 
*       #define     IR_O_XXX            (IR_O_PVTN_XXX_ -1) 
*       #define     IR_O_XXX            (IR_O_PVTN_XXX_ -0) 
*       /-** Private negative O results of X1 object model: ^ **-/
*
*       #define     IR_O_PVTN_XXX_           (IR_O_PVTN_ - x)  /-* the starting-point of X1's private negative O result. *-/
*       #define     IR_O_XXX            (IR_O_PVTN_ - x + 1) 
*       ...     ...     ...     ...     ...     ...  
*       #define     IR_O_XXX            (IR_O_PVTN_ -1) 
*       #define     IR_O_XXX            (IR_O_PVTN_ -0) 
*       /-**
*       ** Non-exclusive negative O results for one object model: ^ 
*       **
*       ** Non-exclusive positive O results for one object model:
*       **-/
*       #define     IR_O_XXX           (IR_O_PVTP_ + 0)  
*       #define     IR_O_XXX           (IR_O_PVTP_ + 1)  
*       ...     ...     ...     ...     ...     ...     
*       #define     IR_O_XXX           (IR_O_PVTP_ + x - 1)  
*       #define     IR_O_PVTP_XXX_           (IR_O_PVTP_ + x)  /-* the starting-point of X1's private positive O result. *-/
*
*       /-** Private positive O results of X1 object model: **-/
*       #define     IR_O_XXX           (IR_O_PVTP_XXX_ + 0)  
*       #define     IR_O_XXX           (IR_O_PVTP_XXX_ + 1)  
*       ...     ...     ...     ...     ...     ...    
*       #define     IR_O_XXX           (IR_O_PVTP_XXX_ + x - 1)  
*       #define     IR_O_PVTP_YYY_           (IR_O_PVTP_XXX_ + x)  /-* the starting-point of X2's private positive O result. *-/
*       ...     ...     ...     ...     ...     ...    
*       ...     ...     ...     ...     ...     ...    
*
*       /-**
*       ** Non-exclusive P results for one object model:
*       **-/ 
*       #define     IR_P_XXX            (IR_P_PVT_ + 0)  
*       #define     IR_P_XXX            (IR_P_PVT_ + 1)  
*       ...     ...     ...     ...     ...     ...     
*       #define     IR_P_XXX            (IR_P_PVT_ + x - 1)  
*       #define     IR_P_PVT_XXX_            (IR_P_PVT_ + x)  /-* the starting-point of X1's private P result. *-/
*
*       /-** Private P results of X1 object model: **-/
*       #define     IR_P_XXX            (IR_P_PVT_XXX_ + 0)  
*       #define     IR_P_XXX            (IR_P_PVT_XXX_ + 1)  
*       ...     ...     ...     ...     ...     ...    
*       #define     IR_P_XXX            (IR_P_PVT_XXX_ + x - 1)  
*       #define     IR_P_PVT_YYY_            (IR_P_PVT_XXX_ + x)  /-* the starting-point of X2's private P result. *-/
*       ...     ...     ...     ...     ...     ...    
*       ...     ...     ...     ...     ...     ...    
*
*/
#define     IR_N_PVT_           (IR_N_PRIVATE_ - 50)  /* < the starting-point of outer private N result. > */
#define     IR_N_UNSHARED       (FR_N_PRIVATE_ - 1)  /* Open, the object is unshared. */
#define     IR_N_FULL           (FR_N_PRIVATE_ - 0)  /* Open, the object reference count is full, can not be opened. */
/* >#define     IR_N_PRIVATE_    (IR_N - x)  /-* < the starting-point of inner private N results. > *-/ */

#define     IR_N_PRIVATE_    (IR_N - 10)  /* < the starting-point of inner private N result. > */
#define     IR_N_INVALIDARG         (IR_N -1) /* invalid argument. */
#define     IR_N        __FR_ON__		/* the starting-point of N result (negative result). */
#define     __IR_ON__       (IR_O_PVTN_ - 1000)  /* the N boundary of O result domain. */

#define     IR_O_PVTN_		(IR_O - 10)  /* < the starting-point of outer private negative O result. > */

#define     IR_O_NOPEN		(IR_O - 2)  /* Close, the object is not opened. */
#define     IR_O_VAINLY     (IR_O - 1)  /* vainly */
#define     IR_O			0			 /* the midpoint of O result (neutral result) domain. */
#define     IR_O_OBSOIX      (IR_O + 1)  /* the exclusive result of object visiting mode of OBS order and non-relay. */
#define     IR_O_SBOOIX      (IR_O + 2)  /* the exclusive result of object visiting mode of SBO order and non-relay. */
#define     IR_O__SBOOIX     (IR_O + 3)  /* the exclusive result of object visiting mode of SBO order and relay. */

#define     IR_O_PVTP_		(IR_O + 10)  /* < the starting-point of outer private positive O result. > */

#define     __IR_OP__       (IR_O_PVTP_ + 1000)  /* the P boundary of O result domain. */
#define     IR_P         __FR_OP__		/* the starting-point of P result (positive result). */
#define     IR_P_PRIVATE_     (IR_P + 10) /* < the starting-point of inner private P result. > */

/* >#define     IR_P_PRIVATE_    (IR_P + x)  /-* < the starting-point of inner private P result. > *-/ */
#define     IR_P_RCZERO       (IR_P_PRIVATE_ + 0) /* Close, the object's reference count is 0. */
#define     IR_P_PVT_         (IR_P_PRIVATE_ + 50) /* < the starting-point of outer private P result. > */

/*
*
* Desc: the detection of N, O, P interface results.
* Remarks: NIR --- Negative IRESULT;
*          OIR --- O  IRESULT;
*          PIR --- Positive IRESULT.
*/
#define     NIR(Result)      ( (IRESULT)(Result) <= __IR_ON__ )  
#define     OIR(Result)      ( ((IRESULT)(Result) > __IR_ON__) && ((IRESULT)(Result) < __IR_OP__) )
#define     PIR(Result)      ( (IRESULT)(Result) >= __IR_OP__ )   


/*
*
* Desc: Classify the interaction.
* Remarks: 1. According to whether needs inputted byte data stream and outputs, the interaction be classified as four:
*          AC0 - not inputs and not outputs;
*          AC1 - not inputs but outputs;
*          AC2 - inputs but not outputs;
*          AC3 - inputs and outputs.
*
*       2. TSI and TSO
*          TSI - the Type of Stream Inputted.
*          TSO - the Type of Stream Outputted.
*/
#define     AC0        0  
#define     AC1        (1 << (sizeof(ACTION)*BYTESIZE - 2))   
#define     AC2        (2 << (sizeof(ACTION)*BYTESIZE - 2))   
#define     AC3        (3 << (sizeof(ACTION)*BYTESIZE - 2))  

/* the mask of the interaction class. */
#define     MSKAC      (3 << (sizeof(ACTION)*BYTESIZE - 2)) 

/*
*
* Desc: Define interaction.
* Remarks: === Template ===
*    
*       /-** Non-exclusive AC0 interactions for one object model: **-/
*       #define     XXX_YYYYY         (AC0 | (AC0_PVT_  + 0))  
*       #define     XXX_YYYYY         (AC0 | (AC0_PVT_  + 1))  
*       ...     ...     ...     ...     ...     ...   
*       #define     XXX_YYYYY         (AC0 | (AC0_PVT_  + x - 1))  
*	    #define     AC1_PVT_          (AC0_PVT_ + x)  /-* the starting-point of non-exclusive AC1 interaction for one object model. *-/ 
*
*       /-** Non-exclusive AC1 interactions for one object model: **-/
*       #define     XXX_YYYYY         (AC1 | (AC1_PVT_  + 0))  
*       #define     XXX_YYYYY         (AC1 | (AC1_PVT_  + 1))  
*       ...     ...     ...     ...     ...     ...   
*       #define     XXX_YYYYY         (AC1 | (AC1_PVT_  + x - 1))  
*	    #define     AC2_PVT_          (AC1_PVT_ + x)  /-* the starting-point of non-exclusive AC2 interaction for one object model. *-/ 
*
*       /-** Non-exclusive AC2 interactions for one object model: **-/
*       #define     XXX_YYYYY         (AC2 | (AC2_PVT_  + 0))  
*       #define     XXX_YYYYY         (AC2 | (AC2_PVT_  + 1))  
*       ...     ...     ...     ...     ...     ...   
*       #define     XXX_YYYYY         (AC2 | (AC2_PVT_  + x - 1))  
*	    #define     AC3_PVT_          (AC2_PVT_ + x)  /-* the starting-point of non-exclusive AC3 interaction for one object model. *-/ 
*
*       /-** Non-exclusive AC3 interactions for one object model: **-/
*       #define     XXX_YYYYY         (AC3 | (AC3_PVT_  + 0))  
*       #define     XXX_YYYYY         (AC3 | (AC3_PVT_  + 1))  
*       ...     ...     ...     ...     ...     ...   
*       #define     XXX_YYYYY         (AC3 | (AC3_PVT_  + x - 1))  
*	    #define     AC0_PVT_XXX_      (AC3_PVT_ + x)  /-* the starting-point of X1's private AC0 interaction. *-/ 
*
*
*       /-** Private AC0 interactions of the X1 object model: **-/
*       #define     XXX_YYYYY         (AC0 | (AC0_PVT_XXX_  + 0))  
*       #define     XXX_YYYYY         (AC0 | (AC0_PVT_XXX_  + 1))  
*       ...     ...     ...     ...     ...     ...   
*       #define     XXX_YYYYY         (AC0 | (AC0_PVT_XXX_  + x - 1))  
*	    #define     AC1_PVT_XXX_      (AC0_PVT_XXX_ + x)  /-* the starting-point of X1's private AC1 interaction. *-/ 
*
*       /-** Private AC1 interactions of the X1 object model: **-/
*       #define     XXX_YYYYY         (AC1 | (AC1_PVT_XXX_  + 0))  
*       #define     XXX_YYYYY         (AC1 | (AC1_PVT_XXX_  + 1))  
*       ...     ...     ...     ...     ...     ...   
*       #define     XXX_YYYYY         (AC1 | (AC1_PVT_XXX_  + x - 1))  
*	    #define     AC2_PVT_XXX_      (AC1_PVT_XXX_ + x)  /-* the starting-point of X1's private AC2 interaction. *-/ 
*
*       /-** Private AC2 interactions of the X1 object model: **-/
*       #define     XXX_YYYYY         (AC2 | (AC2_PVT_XXX_  + 0))  
*       #define     XXX_YYYYY         (AC2 | (AC2_PVT_XXX_  + 1))  
*       ...     ...     ...     ...     ...     ...   
*       #define     XXX_YYYYY         (AC2 | (AC2_PVT_XXX_  + x - 1))  
*	    #define     AC3_PVT_XXX_      (AC2_PVT_XXX_ + x)  /-* the starting-point of X1's private AC3 interaction. *-/ 
*
*       /-** Private AC3 interactions of the X1 object model: **-/
*       #define     XXX_YYYYY         (AC3 | (AC3_PVT_XXX_  + 0))  
*       #define     XXX_YYYYY         (AC3 | (AC3_PVT_XXX_  + 1))  
*       ...     ...     ...     ...     ...     ...   
*       #define     XXX_YYYYY         (AC3 | (AC3_PVT_XXX_  + x - 1))  
*	    #define     AC0_PVT_YYY_      (AC3_PVT_XXX_ + x)  /-* the starting-point of X2's private AC0 interaction. *-/ 
*
*
*       /-** Private AC0 interactions of the X2 object model: **-/
*       ...     ...     ...     ...     ...     ...  
*
*       ...     ...     ...     ...     ...     ...
*               
*/
#define    AC0_                0

/** AC0 interactions: **/
#define    ASK_SHARED         (AC0 | (AC0_  + 0))   /* Is the object shared? */
#define    SET_SHARED         (AC0 | (AC0_  + 1))   /* Set the object to be shared. */
#define    SET_UNSHARED       (AC0 | (AC0_  + 2))   /* Set the object to be unshared. */
#define    SET_BLOCKI         (AC0 | (AC0_  + 3))   /* Set the object to be blocked input. */
#define    SET_UNBLOCKI       (AC0 | (AC0_  + 4))   /* Set the object to be non-blocked input. */
#define    SET_BLOCKO         (AC0 | (AC0_  + 5))   /* Set the object to be blocked output. */
#define    SET_UNBLOCKO       (AC0 | (AC0_  + 6))   /* Set the object to be non-blocked output. */
#define    CMD_RESET          (AC0 | (AC0_  + 7))   /* Reset. */
#define    AC1_               (AC0_ + 8)  /* the starting-point of AC1 interaction. */ 

/** AC1 interactions: **/
#define    GET_IQCTY          (AC1 | (AC1_  + 0))   /* Get the capacity of IQ. */
#define    GET_OQCTY          (AC1 | (AC1_  + 1))   /* Get the capacity of OQ. */
#define    AC2_               (AC1_ + 2)  /* the starting-point of AC2 interaction. */ 

/** AC2 interactions: **/
#define    SET_IQCTY          (AC2 | (AC2_  + 0))   /* Set the capacity of IQ. */
#define    SET_OQCTY          (AC2 | (AC2_  + 1))   /* Set the capacity of OQ. */
#define    AC3_               (AC2_ + 2)  /* the starting-point of AC3 interaction. */ 

/** AC3 interactions: **/
/* ...     ...     ...     ...     ...     ... */
#define    AC0_PVT_           (AC3_  + 0)    /* < the starting-point of outer private AC0 interaction. > */


/*
*
* Desc: Define the executive results of function(s).
* Remarks: === Template ===
*
*       ...     ...     ...     ...     ...     ...    
*       ...     ...     ...     ...     ...     ...    
*       #define     FR_N_PVT_YYY_            (FR_N_PVT_XXX_ - x)  /-* the starting-point of X2's private N result. *-/
*       #define     FR_N_XXX            (FR_N_PVT_XXX_ - x + 1) 
*       ...     ...     ...     ...     ...     ... 
*       #define     FR_N_XXX            (FR_N_PVT_XXX_ -1) 
*       #define     FR_N_XXX            (FR_N_PVT_XXX_ -0) 
*       /-** Private N results of X1 function: ^ **-/
*
*       #define     FR_N_PVT_XXX_            (FR_N_PVT_ - x)  /-* the starting-point of X1's private N result. *-/
*       #define     FR_N_XXX            (FR_N_PVT_ - x + 1) 
*       ...     ...     ...     ...     ...     ...  
*       #define     FR_N_XXX            (FR_N_PVT_ -1) 
*       #define     FR_N_XXX            (FR_N_PVT_ -0) 
*       /-** 
*       ** Non-exclusive N results for one function: ^
*       **-/
*
*       ...     ...     ...     ...     ...     ...    
*       ...     ...     ...     ...     ...     ...    
*       #define     FR_O_PVTN_YYY_           (FR_O_PVTN_XXX_ - x)  /-* the starting-point of X2's private negative O result. *-/
*       #define     FR_O_XXX            (FR_O_PVTN_XXX_ - x + 1) 
*       ...     ...     ...     ...     ...     ... 
*       #define     FR_O_XXX            (FR_O_PVTN_XXX_ -1) 
*       #define     FR_O_XXX            (FR_O_PVTN_XXX_ -0) 
*       /-** Private negative O results of X1 function: ^ **-/
* 
*       #define     FR_O_PVTN_XXX_           (FR_O_PVTN_ - x)  /-* the starting-point of X1's private negative O result. *-/
*       #define     FR_O_XXX            (FR_O_PVTN_ - x + 1) 
*       ...     ...     ...     ...     ...     ...  
*       #define     FR_O_XXX            (FR_O_PVTN_ -1) 
*       #define     FR_O_XXX            (FR_O_PVTN_ -0) 
*       /-**
*       ** Non-exclusive negative O results for one function: ^ 
*       **
*       ** Non-exclusive positive O results for one function:
*       **-/
*       #define     FR_O_XXX            (FR_O_PVTP_ + 0)  
*       #define     FR_O_XXX            (FR_O_PVTP_ + 1)  
*       ...     ...     ...     ...     ...     ...     
*       #define     FR_O_XXX            (FR_O_PVTP_ + x - 1)  
*       #define     FR_O_PVTP_XXX_           (FR_O_PVTP_ + x)  /-* the starting-point of X1's private positive O result. *-/
*
*       /-** Private positive O results of X1 function: **-/
*       #define     FR_O_XXX            (FR_O_PVTP_XXX_ + 0)  
*       #define     FR_O_XXX            (FR_O_PVTP_XXX_ + 1)  
*       ...     ...     ...     ...     ...     ...    
*       #define     FR_O_XXX            (FR_O_PVTP_XXX_ + x - 1)  
*       #define     FR_O_PVTP_YYY_           (FR_O_PVTP_XXX_ + x)  /-* the starting-point of X2's private positive O result. *-/
*       ...     ...     ...     ...     ...     ...    
*       ...     ...     ...     ...     ...     ...  
*  
*       /-** 
*       ** Non-exclusive P results for one function:
*       **-/ 
*       #define     FR_P_XXX            (FR_P_PVT_ + 0)  
*       #define     FR_P_XXX            (FR_P_PVT_ + 1)  
*       ...     ...     ...     ...     ...     ...     
*       #define     FR_P_XXX            (FR_P_PVT_ + x - 1)  
*       #define     FR_P_PVT_XXX_            (FR_P_PVT_ + x)  /-* the starting-point of X1's private P result. *-/
*
*       /-** Private P results of X1 function: **-/
*       #define     FR_P_XXX            (FR_P_PVT_XXX_ + 0)  
*       #define     FR_P_XXX            (FR_P_PVT_XXX_ + 1)  
*       ...     ...     ...     ...     ...     ...    
*       #define     FR_P_XXX            (FR_P_PVT_XXX_ + x - 1)  
*       #define     FR_P_PVT_YYY_            (FR_P_PVT_XXX_ + x)  /-* the starting-point of X2's private P result. *-/
*       ...     ...     ...     ...     ...     ...    
*       ...     ...     ...     ...     ...     ...    
*  
*/
#define     FR_N_PVT_            (FR_N_PRIVATE_ - 50)  /* < the starting-point of outer private N result. > */
#define     FR_N_LACKOID         (FR_N_PRIVATE_ - 2)  /* __CreateObject__, not has enough OID to assign. */
#define     FR_N_HASVR           (FR_N_PRIVATE_ - 1)  /* CallerCome, the VR has been in. */
#define     FR_N_LOST            (FR_N_PRIVATE_ - 0)  /* Enqueue/Dequeue, the Byte(s) has(have) lost. */
/* >#define     FR_N_PRIVATE_        (FR_N - x)  /-* < the starting-point of inner private N results. > *-/ */

#define     FR_N_PRIVATE_        (FR_N - 10)  /* < the starting-point of inner private N results. > */
#define     FR_N_INVALIDARG      (FR_N -1) /* invalid argument. */
#define     FR_N        __FR_ON__  /* the starting-point of N result (negative result). */
#define     __FR_ON__       (FR_O_PVTN_ - 1000)  /* the N boundary of O result domain. */

#define     FR_O_PVTN_		(FR_O - 10)  /* < the starting-point of outer private negative O result. > */

#define     FR_O_VAINLY			(FR_O - 1)  /* vainly */
#define     FR_O				0			/* the midpoint of O result (neutral result) domain. */

#define     FR_O_PVTP_		(FR_O + 10)  /* < the starting-point of outer private positive O result. > */

#define     __FR_OP__       (FR_O_PVTP_ + 1000)  /* the P boundary of O result domain. */
#define     FR_P         __FR_OP__   /* the starting-point of P result (positive result). */
#define     FR_P_PRIVATE_        (FR_P + 10)  /* < the starting-point of inner private P result. > */

/* >#define     FR_P_PRIVATE_        (FR_P + x)  /-* < the starting-point of inner private P result. >*-/ */
#define     FR_P_PVT_            (FR_P_PRIVATE_ + 0)  /* < the starting-point of outer private P result. > */

/*
*
* Desc: the detection of N, O, P function results.
* Remarks: NFR --- Negative FRESULT;
*          OFR --- O  FRESULT;
*          PFR --- Positive FRESULT.
*/
#define     NFR(Result)      ( (FRESULT)(Result) <= __FR_ON__ )
#define     OFR(Result)      ( ((FRESULT)(Result) > __FR_ON__) && ((FRESULT)(Result) < __FR_OP__) )
#define     PFR(Result)      ( (FRESULT)(Result) >= __FR_OP__ )

/*
*
* boolean values and null pointer value.
*/
#undef TRUE
#undef FALSE
#undef NULL

#define TRUE          1      /* Boolean value: true */
#define FALSE         0      /* Boolean value: false */
#define NULL          0      /* pointer value: null */


/*======================+  OIOIC  +======================*/

/*
*
* Desc: queue structure.
* Remarks: q_, pq_.
*/
typedef struct TAG_QUEUE
{
   BYTE*    Dtrm; /* Data Room.*/
   BYTKTY   Cty;  /* the Dtrm's capacity. */
   BYTE*    Front;  /* the address of current first byte. */
   BYTE*    Rear;  /* the address of current last byte. */
   BYTKTY   Qty;  /* the quantity of byte in the Dtrm. */
   BYTKTY   Lost;  /* the quantity of lost byte, for the Dtrm being full. */
}QUEUE;


/*
*
* Desc: VR structure.
* Remarks: vr_, pvr_.
*/
typedef struct TAG_VR
{
	OBJID    cr;  /* CR's ID��*/
	OBJID    mr;  /* MR's ID��*/
}VR;   

/*
*
* Desc: EM data type.
* Remarks: 1. em_, pem_;
*          2. The actual extended members of the object must be placed in the following format EM structure.
*		      typedef struct TAG_EM_XXX
*			  {
*			  	 ...
*			  }EM_XXX;
*/
typedef    VOID     EM;  /* EM data type. */


/*
*
* Desc: OIOIC object model structure.
* Remarks: the "OIOIC" is the combination of the first characters of the "Open", "Input", "Output", "Interact" and 
*          "Close" five common interfaces.
*/
typedef struct TAG_OBJECT
{   
   /* RefCnt, the Reference Count of object. */
   REFCNT     RefCnt;

   /* MSN, Mold's Serial Number. */  
   MLDSN      MSN;
   
   /* OID, object's ID. */  
   OBJID      OID; 
   
   /* for..., require the following two members: 
   * po_AND: points the AND��
   * NND: the Number of ND of IC, that is the number of element in the AND. */
   struct TAG_OBJECT*   po_AND; 
   NUMND      NND; 
   
   /* In order to efficiently visit IBN, require the following two members: 
   * ppo_AIB: points the array of AIB.
   * NIB: the Number of IB, that is the number of element in the AIB. */
   struct TAG_OBJECT**  ppo_AIB;
   NUMIB      NIB; 
   
   /* In order to access the EM of BN and efficiently clean out visiting records, require the following two members:
   * ppo_ABN: points the array of ABN.
   * NBN: the Number of BN, that is the number of element in the ABN. */
   struct TAG_OBJECT**  ppo_ABN;
   NUMBN	  NBN; 
   
   /* the visiting rule of Not Reentrant, that is, the same CR of the same MR can only visit each BN once.
   * To comply with the "Not Reentrant" rule, require the following two members:
   * pvr_ACS: points the ACS��
   * NCS: the Number of CS, that is the number of element in the ACS. */
   VR*        pvr_ACS;
   NUMCS      NCS;    
   
   /** Object's interfaces: Open, Input, Output, IOput, Interact0~3, Close. **/
   
   /* Name: Open
   *  Desc: Opens the object.
   *  Para: pCaller --- [IN] points the VR. */
   IRESULT  (*Open) (struct TAG_OBJECT* This, const VR* pCaller);
   /* Name: Input
   *  Desc: Inputs stream.
   *  Para: IStrm --- [IN] the inputted stream;
   *        Qty --- [IN] the quantity of inputted byte;
   *        pCaller --- [IN] points the VR. */
   IRESULT  (*Input) (struct TAG_OBJECT* This, BYTE* IStrm, BYTKTY Qty, const VR* pCaller);
   /* Name: Output
   *  Desc: Outputs stream.
   *  Para: OStrm --- [OUT] saves the outputted stream;
   *        Cty --- [IN] the OStrm's capacity;
   *        pQty --- [OUT] saves the actual quantity of byte outputted;
   *        pCaller --- [IN] points the VR. */
   IRESULT  (*Output) (struct TAG_OBJECT* This, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller);
   /* Name: IOput
   *  Desc: Inputs and outputs stream;
   *  Para: IStrm --- [IN] the inputted stream;
   *        Qty --- [IN] the quantity of byte inputted;
   *        OStrm --- [OUT] saves the outputted stream;
   *        Cty --- [IN] the OStrm's capacity;
   *        pQty --- [OUT] saves the actual quantity of byte outputted;
   *        pCaller --- [IN] points the VR. */
   IRESULT  (*IOput) (struct TAG_OBJECT* This, BYTE* IStrm, BYTKTY Qty, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller);
   /* Name: Interact0
   *  Desc: Interacts by interaction of AC0.
   *  Para: Act --- [IN] interaction;
   *        pCaller --- [IN] points the VR. */
   IRESULT  (*Interact0) (struct TAG_OBJECT* This, ACTION Act, const VR* pCaller);
   /* Name: Interact1
   *  Desc: Interacts by interaction of AC1.
   *  Para: Act --- [IN] interaction;
   *        OStrm --- [OUT] saves the outputted stream;
   *        Cty --- [IN] the OStrm's capacity;
   *        pQty --- [OUT] saves the actual quantity of byte outputted;
   *        pCaller --- [IN] points the VR. */
   IRESULT  (*Interact1) (struct TAG_OBJECT* This, ACTION Act, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller);
   /* Name: Interact2
   *  Desc: Interacts by interaction of AC2.
   *  Para: Act --- [IN] interaction;
   *        IStrm --- [IN] the inputted stream;
   *        Qty --- [IN] the quantity of byte inputted;
   *        pCaller --- [IN] points the VR. */
   IRESULT  (*Interact2) (struct TAG_OBJECT* This, ACTION  Act, BYTE* IStrm, BYTKTY Qty, const VR* pCaller);
   /* Name: Interact3
   *  Desc: Interacts by interaction of AC3.
   *  Para: Act --- [IN] interaction;
   *        IStrm --- [IN] the inputted stream;
   *        Qty --- [IN] the quantity of byte inputted;
   *        OStrm --- [OUT] saves the outputted stream;
   *        Cty --- [IN] the OStrm's capacity;
   *        pQty --- [OUT] saves the actual quantity of byte outputted;
   *        pCaller --- [IN] points the VR. */
   IRESULT  (*Interact3) (struct TAG_OBJECT* This, ACTION Act, BYTE* IStrm, BYTKTY Qty, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller);
   /* Name: Close
   *  Desc: Close the object.
   *  Para: pCaller --- [IN] points the VR. */
   IRESULT  (*Close) (struct TAG_OBJECT* This, const VR* pCaller);
   
   /* pEM, points the object's EM (Extended Member). */
   EM*   pEM;   
}OBJECT;

/*====================+ OIOIC's EM +=====================*/

typedef struct TAG_EM_OIOIC
{ 
	QUEUE	   IQ;	/* input queue. */  
	QUEUE	   OQ;  /* output queue. */  
	MODES      mds;	/* modes */
}EM_OIOIC;

/*=============+ enqueue or dequeue a byte +=============*/

/* Two modes to enqueue a byte:
*  1. PLACE ---  place a byte into a queue that has free space;
*  2. PUSH --- push a byte into a queue that is full (has not free space), extrude the first byte. */

/*
*
* Name: ENQ_PLACE_BYTE
* Desc: places a byte into a queue that has free space.
* Para: pQ --- [IN] points a queue that must have free space; 
*       byte --- [IN] the byte to enqueue.
* Remarks: Only applies to a queue that has free space. As follows,
*
*		 if(pQ->Qty < pQ->Cty)
*		 { 
*		  	ENQ_PLACE_BYTE(pQ, byte);
*		 }else
*		 {
*		 	pQ->Lost++; 
* 
*	 		/-* ... *-/
*		 }
*/
#define  ENQ_PLACE_BYTE(pQ, byte) \
	do{ \
		if((pQ)->Rear == (pQ)->Dtrm + (pQ)->Cty - 1) \
			(pQ)->Rear = (pQ)->Dtrm; \
		else \
			(pQ)->Rear++; \
		*((pQ)->Rear) = (byte); \
		(pQ)->Qty++; \
		if((pQ)->Dtrm-1 == (pQ)->Front) \
			(pQ)->Front = (pQ)->Dtrm; \
	}while(0)

/*
*
* Name: ENQ_PUSH_BYTE
* Desc: pushes a byte into a queue that is full (has not free space), extrudes the first byte.
* Para: pQ --- [IN] points a queue; 
*       byte --- [IN] the byte to enqueue.
* Remarks: Only applies to a queue that is full. As follows,
*
*	  	 if(pQ->Qty < pQ->Cty)
*		 {
*			ENQ_PLACE_BYTE(pQ, byte);
*		 }else
*		 {
*		 	ENQ_PUSH_BYTE(pQ, byte);
*		 	pQ->Lost++; 
* 
*			/-* ... *-/
*		 }
*/
#define  ENQ_PUSH_BYTE(pQ, byte) \
	do{ \
		(pQ)->Rear = (pQ)->Front; \
		*((pQ)->Rear) = (byte); \
		if( (pQ)->Front == ((pQ)->Dtrm + (pQ)->Cty -1) ) \
			(pQ)->Front = (pQ)->Dtrm; \
		else \
			(pQ)->Front++; \
	}while(0)

/*
*
* Name: DEQ_BYTE
* Desc: Dequeues a byte from a non-empty queue.
* Para: pQ --- [IN] points a queue; 
*       pByte --- [OUT] saving the dequeued byte.
* Remarks: Only applies to a non-empty queue. As follows,
*
*	  	 if(pQ->Qty > 0)
*		 {
*			DEQ_BYTE(pQ, pByte);
*		 }
*/
#define  DEQ_BYTE(pQ, pByte) \
	do{ \
		*(pByte) = *((pQ)->Front); \
		(pQ)->Qty--; \
		if(0 == (pQ)->Qty) \
			(pQ)->Front = (pQ)->Rear = (pQ)->Dtrm -1; \
		else if( (pQ)->Front == ((pQ)->Dtrm + (pQ)->Cty -1) ) \
			(pQ)->Front = (pQ)->Dtrm; \
		else \
			(pQ)->Front++; \
	}while(0)


/*================+ inline VO functions +================*/

/* NODE: the function of inlined VO functions and that of non-inlined are identical. */
 

#if INLINE_VOFUNCTION == 1

/**
*
* Name: VO_Open
* Desc: the VO function of the "Open" interface.
* Para: pObject --- [IN] points the object;
*       pCaller --- [IN] points the VR.
*/    	             
static  _INLINE_  IRESULT  VO_Open(OBJECT* pObject, const VR* pCaller)
{
	extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller);
	extern  FRESULT CallerLeave(OBJECT* pND, const VR* pCaller);

	IRESULT  ir = IR_O;

	assert( pObject != NULL );
	assert( pCaller->cr != 0 );
	assert( pCaller->mr != 0 );
	
	if( FR_P == CallerCome(pObject, pCaller) )
	{
		ir = pObject->Open(pObject, pCaller);
		CallerLeave(pObject, pCaller);
	}else { ir = IR_N; }
	
	return ir;
}
       
/**
*
* Name: VO_Input
* Desc: the VO function of the "Input" interface.
* Para: pObject --- [IN] points the object; 
*      IStrm --- [IN] inputted stream;
*      Qty --- [IN] the quantity of inputted byte;
*      pCaller --- [IN] points the VR.
*/          
static  _INLINE_  IRESULT  VO_Input(OBJECT* pObject, BYTE* IStrm, BYTKTY Qty, const VR* pCaller)
{
	extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller);
	extern  FRESULT CallerLeave(OBJECT* pND, const VR* pCaller);

	IRESULT  ir = IR_O;

	assert( pObject != NULL );
	assert( IStrm != NULL );
	assert( Qty > 0 );
	assert( pCaller->cr != 0 );
	assert( pCaller->mr !=0 );

	if( FR_P == CallerCome(pObject, pCaller) ) 
	{ 
		ir = pObject->Input(pObject, IStrm, Qty, pCaller); 
		CallerLeave(pObject, pCaller); 
	}else { ir = IR_N; }
	
	return ir;
}

/**
*
* Name: VO_Output
* Desc: the VO function of the "Output" interface.
* Para: pObject --- [IN] points the object;  
*      OStrm --- [OUT] saves the outputted stream;
*      Cty --- [IN] the OStrm's capacity;
*      pQty --- [OUT] saves the actual quantity of byte outputted;
*      pCaller --- [IN] points the VR.
*/      
static  _INLINE_  IRESULT  VO_Output(OBJECT* pObject, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller) 
{
	extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller);
	extern  FRESULT CallerLeave(OBJECT* pND, const VR* pCaller);

	IRESULT  ir = IR_O;

	assert( pObject != NULL );
	assert( OStrm != NULL );
	assert( Cty > 0 );
	assert( pQty != NULL );
	assert( pCaller->cr != 0 );
	assert( pCaller->mr != 0 );

	*pQty = 0;

	if( FR_P == CallerCome(pObject, pCaller) ) 
	{ 
		ir = pObject->Output(pObject, OStrm, Cty, pQty, pCaller); 
		CallerLeave(pObject, pCaller); 
	}else { ir = IR_N; }
	
	return ir;
}

/**
*
* Name: VO_IOput
* Desc: the VO function of the "IOput" interface.
* Para: pObject --- [IN] points the object;  
*       IStrm --- [IN] inputted stream;
*       Qty --- [IN] the quantity of inputted byte;
*       OStrm --- [OUT] saves the outputted stream;
*       Cty --- [IN] the OStrm's capacity;
*       pQty --- [OUT] saves the actual quantity of byte outputted;
*       pCaller --- [IN] points the VR.
*/  
static  _INLINE_  IRESULT  VO_IOput(OBJECT* pObject, BYTE* IStrm, BYTKTY Qty, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller)
{
	extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller);
	extern  FRESULT CallerLeave(OBJECT* pND, const VR* pCaller);
	
	IRESULT  ir = IR_O;

	assert( pObject != NULL );
	assert( IStrm != NULL );
	assert( Qty > 0 );
	assert( OStrm != NULL );
	assert( Cty > 0 );
	assert( pQty != NULL );
	assert( pCaller->cr != 0 );
	assert( pCaller->mr != 0 );
	
	*pQty = 0;

	if( FR_P == CallerCome(pObject, pCaller) ) 
	{ 
		ir = pObject->IOput(pObject, IStrm, Qty, OStrm, Cty, pQty, pCaller); 
		CallerLeave(pObject, pCaller); 
	}else { ir = IR_N; }
	
	return ir;
}

/**
*
* Name: VO_Interact0
* Desc: the VO function of the "Interact0" interface.
* Para: pObject --- [IN] points the object; 
*       Act --- [IN] interaction;
*       pCaller --- [IN] points the VR.
*/	       
static  _INLINE_  IRESULT  VO_Interact0(OBJECT* pObject, ACTION Act, const VR* pCaller) 
{
	extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller);
	extern  FRESULT CallerLeave(OBJECT* pND, const VR* pCaller);

	IRESULT  ir = IR_O;

	assert( pObject != NULL );
	assert( (MSKAC & Act) == AC0 );
	assert( pCaller->cr != 0 );
	assert( pCaller->mr != 0 );
	
	if( FR_P == CallerCome(pObject, pCaller) )
	{
		ir = pObject->Interact0(pObject, Act, pCaller);
		CallerLeave(pObject, pCaller);
	}else { ir = IR_N; }
	
	return ir;
}

/**
*
* Name: VO_Interact1
* Desc: the VO function of the "Interact1" interface.
* Para: pObject --- [IN] points the object; 
*       Act --- [IN] interaction;
*       OStrm --- [OUT] saves the outputted stream;
*       Cty --- [IN] the OStrm's capacity;
*       pQty --- [OUT] saves the actual quantity of byte outputted;
*       pCaller --- [IN] points the VR.
*/       
static  _INLINE_  IRESULT  VO_Interact1(OBJECT* pObject, ACTION Act, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller) 
{
	extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller);
	extern  FRESULT CallerLeave(OBJECT* pND, const VR* pCaller);

	IRESULT  ir = IR_O;

	assert( pObject != NULL );
	assert( (MSKAC & Act) == AC1 );
	assert( OStrm != NULL );
	assert( Cty > 0 );
	assert( pQty != NULL );
	assert( pCaller->cr != 0 );
	assert( pCaller->mr != 0 );

	*pQty = 0;

	if( FR_P == CallerCome(pObject, pCaller) ) 
	{ 
		ir = pObject->Interact1(pObject, Act, OStrm, Cty, pQty, pCaller); 
		CallerLeave(pObject, pCaller); 
	}else { ir = IR_N; }
	
	return ir;
}

/**
*
* Name: VO_Interact2
* Desc: the VO function of the "Interact2" interface.
* Para: pObject --- [IN] points the object; 
*       Act --- [IN] interaction;
*       IStrm --- [IN] inputted stream;
*       Qty --- [IN] the quantity of inputted byte;
*       pCaller --- [IN] points the VR.
*/       
static  _INLINE_  IRESULT  VO_Interact2(OBJECT* pObject, ACTION Act, BYTE* IStrm, BYTKTY Qty, const VR* pCaller)  
{
	extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller);
	extern  FRESULT CallerLeave(OBJECT* pND, const VR* pCaller);

	IRESULT  ir = IR_O;
	
	assert( pObject != NULL );
	assert( (MSKAC & Act) == AC2 );
	assert( IStrm != NULL );
	assert( Qty > 0 );
	assert( pCaller->cr != 0 );
	assert( pCaller->mr != 0 );

	if( FR_P == CallerCome(pObject, pCaller) ) 
	{ 
		ir = pObject->Interact2(pObject, Act, IStrm, Qty, pCaller); 
		CallerLeave(pObject, pCaller); 
	}else { ir = IR_N; }
	
	return ir;
}

/**
*
* Name: VO_Interact3
* Desc: the VO function of the "Interact3" interface.
* Para: pObject --- [IN] points the object; 
*       Act --- [IN] interaction;
*       IStrm --- [IN] inputted stream;
*       Qty --- [IN] the quantity of inputted byte;
*       OStrm --- [OUT] saves the outputted stream;
*       Cty --- [IN] the OStrm's capacity;
*       pQty --- [OUT] saves the actual quantity of byte outputted;
*       pCaller --- [IN] points the VR.
*/       
static  _INLINE_  IRESULT  VO_Interact3(OBJECT* pObject, ACTION Act, BYTE* IStrm, BYTKTY Qty, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller)  
{
	extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller);
	extern  FRESULT CallerLeave(OBJECT* pND, const VR* pCaller);

	IRESULT  ir = IR_O;

	assert( pObject != NULL );
	assert( (MSKAC & Act) == AC3 );
	assert( IStrm != NULL );
	assert( Qty > 0 );
	assert( OStrm != NULL );
	assert( Cty > 0 );
	assert( pQty != NULL );
	assert( pCaller->cr != 0 );
	assert( pCaller->mr != 0 );

	*pQty = 0;

	if( FR_P == CallerCome(pObject, pCaller) ) 
	{ 
		ir = pObject->Interact3(pObject, Act, IStrm, Qty, OStrm, Cty, pQty, pCaller); 
		CallerLeave(pObject, pCaller); 
	}else { ir = IR_N; }
	
	return ir;
}

/**
*
* Name: VO_Close
* Desc: the VO function of the "Close" interface.
* Para: pObject --- [IN] points the object;  
*       pCaller --- [IN] points the VR.
*/       
static  _INLINE_  IRESULT  VO_Close(OBJECT* pObject, const VR* pCaller) 
{
	extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller);
	extern  FRESULT CallerLeave(OBJECT* pND, const VR* pCaller);

	IRESULT  ir = IR_O;
	
	assert( pObject != NULL );
	assert( pCaller->cr != 0 );
	assert( pCaller->mr != 0 );

	if( FR_P == CallerCome(pObject, pCaller) ) 
	{ 
		ir = pObject->Close(pObject, pCaller); 
		CallerLeave(pObject, pCaller); 
	}else { ir = IR_N; }
	
	return ir;
}

#endif

/*=====+ Four visiting modes of inheritance chain +======*/

/*  
* 1. Two visiting orders of inheritance chain: OBS and SBO.
*    (1) OBS, others before self, i.e. first visits the node's IBN(s) then visits the node itself;
*    (2) SBO, self before others, i.e. first visits the node itself then visits the node's IBN(s).
*
* 2. Two visiting methods of inheritance chain: Relay Visiting and Non-relay Visiting.
*     (1) Relay Visiting, after visited the previous node, no matter what the executive 
*         result, visits the next node. In OBS, returns the LND's executive result; In SBO, 
*         returns the FND's executive result in the Single Inheritance, returns IR_O__SBOOIX 
*         in the Multiple Inheritance.    
*     (2) Non-Relay Visiting, after visited on the previous node, if the result is not IR_O_OBSOIX 
*         (for OBS) or IR_O_SBOOIX (for SBO), returns executive result, otherwise, visits the next node.  
*
* 3. The two visiting orders combine with the two visiting methods to form four visiting modes of inheritance chain.
*     (1) OBS_O_IX, the OBS_OBJECT_<INTERFACE> type of macro, visits non-relaily by OBS order;
*     (2) OBS_O_IX_, the OBS_OBJECT_<INTERFACE>_ type of macro, visits relaily by OBS order;
*     (3) SBO_O_IX, the SBO_OBJECT_<INTERFACE> type of macro, visits non-relaily by SBO order;
*     (4) _SBO_O_IX, the _SBO_OBJECT_<INTERFACE> type of macro, visits relaily by SBO order.
*
* NOTE: (1) The "Open" and "Close" interfaces can only be visited relaily by OBS order, so that they 
*           have not the OBS_O_IX, SBO_O_IX and _SBO_O_IX.
*       (2) In an interface, can only select one in the four visiting modes, should not have two different modes.
*       (3) The Relay Visiting is generally applicable to the Single Inheritance, little significance for the Multiple Inheritance.
*/

/*
*
* Name: OBS_OBJECT_OPEN_
* Desc: the OBS_O_IX_ of "Open" interface.
*/
#define  OBS_OBJECT_OPEN_ \
	do{ \
		IRESULT  ir; \
		IRESULT  fr; \
		NUMIB	 i; \
		VR	Caller; \
		EM_OIOIC*  pem = (EM_OIOIC*)GetEMofBN(This, MSN_OIOIC); \
		Caller.cr = pCaller->cr; \
		Caller.mr = This->OID; \
  		if(0 == ++This->RefCnt) \
		{ \
			This->RefCnt--; \
			return  IR_N_FULL; \
		} \
		if(!(MOD_SHARED & pem->mds) || 1 == This->RefCnt) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			for(i=0; i<This->NIB; i++) \
			{ \
				fr = CallerCome(*(This->ppo_AIB+i), pCaller); \
				if(FR_P == fr) ir = (*(This->ppo_AIB+i))->Open(*(This->ppo_AIB+i), pCaller); \
				else if(FR_N_HASVR == fr) continue; \
				else ir = IR_N; \
				if( NIR(ir) ) \
				{ \
					NUMIB  j; \
					for( j=0; j<i; j++) \
					{ \
						if((*(This->ppo_AIB+j))->RefCnt == This->RefCnt) \
							VO_Close(*(This->ppo_AIB+j), &Caller); \
					} \
					This->RefCnt--; \
					return ir; \
				} \
			} \
		}else \
		{ \
			This->RefCnt--; \
			return IR_N_UNSHARED; \
		} \
	}while(0)
	
/*
*
* Name: OBS_OBJECT_INPUT
* Desc: the OBS_O_IX of "Input" interface.
*/
#define  OBS_OBJECT_INPUT \
	do{ \
		IRESULT  ir = IR_O_OBSOIX; \
		IRESULT  fr; \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			fr = CallerCome(*(This->ppo_AIB+i), pCaller); \
			if(FR_P == fr) ir = (*(This->ppo_AIB+i))->Input(*(This->ppo_AIB+i), IStrm, Qty, pCaller); \
			else if(FR_N_HASVR == fr) continue; \
			else ir = IR_N; \
			if(ir != IR_O_OBSOIX) return ir; \
		} \
	}while(0)

/*
*
* Name: OBS_OBJECT_INPUT_
* Desc: the OBS_O_IX_ of "Input" interface.
*/
#define  OBS_OBJECT_INPUT_ \
	do{ \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			if(FR_P == CallerCome(*(This->ppo_AIB+i), pCaller)) \
				(*(This->ppo_AIB+i))->Input(*(This->ppo_AIB+i), IStrm, Qty, pCaller); \
		} \
	}while(0)

/*
*
* Name: SBO_OBJECT_INPUT
* Desc: the SBO_O_IX of "Input" interface.
*/
#define  SBO_OBJECT_INPUT \
	do{ \
		IRESULT  ir = IR_O_SBOOIX; \
		IRESULT  fr; \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			fr = CallerCome(*(This->ppo_AIB+i), pCaller); \
			if(FR_P == fr) ir = (*(This->ppo_AIB+i))->Input(*(This->ppo_AIB+i), IStrm, Qty, pCaller); \
			else if(FR_N_HASVR == fr) continue; \
			else ir = IR_N; \
			if(ir != IR_O_SBOOIX) return ir; \
		} \
		return ir; \
	}while(0)

/*
*
* Name: _SBO_OBJECT_INPUT
* Desc: the _SBO_O_IX of "Input" interface.
*/
#define  _SBO_OBJECT_INPUT \
	do{ \
		IRESULT  ir = IR_O__SBOOIX; \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			if(FR_P == CallerCome(*(This->ppo_AIB+i), pCaller)) \
				ir = (*(This->ppo_AIB+i))->Input(*(This->ppo_AIB+i), IStrm, Qty, pCaller); \
		} \
		return ir; \
	}while(0)
	
/*
*
* Name: OBS_OBJECT_OUTPUT
* Desc: the OBS_O_IX of "Output" interface.
*/
#define  OBS_OBJECT_OUTPUT \
	do{ \
		IRESULT  ir = IR_O_OBSOIX;  \
		IRESULT  fr; \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			fr = CallerCome(*(This->ppo_AIB+i), pCaller); \
			if(FR_P == fr) ir = (*(This->ppo_AIB+i))->Output(*(This->ppo_AIB+i), OStrm, Cty, pQty, pCaller); \
			else if(FR_N_HASVR == fr) continue; \
			else ir = IR_N; \
			if(ir != IR_O_OBSOIX) return ir; \
		} \
	}while(0)

/*
*
* Name: OBS_OBJECT_OUTPUT_
* Desc: the OBS_O_IX_ of "Output" interface.
*/
#define  OBS_OBJECT_OUTPUT_ \
	do{ \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			if(FR_P == CallerCome(*(This->ppo_AIB+i), pCaller)) \
				(*(This->ppo_AIB+i))->Output(*(This->ppo_AIB+i), OStrm, Cty, pQty, pCaller); \
		} \
	}while(0)

/*
*
* Name: SBO_OBJECT_OUTPUT
* Desc: the SBO_O_IX of "Output" interface.
*/
#define  SBO_OBJECT_OUTPUT \
	do{ \
		IRESULT  ir = IR_O_SBOOIX; \
		IRESULT  fr; \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			fr = CallerCome(*(This->ppo_AIB+i), pCaller); \
			if(FR_P == fr) ir = (*(This->ppo_AIB+i))->Output(*(This->ppo_AIB+i), OStrm, Cty, pQty, pCaller); \
			else if(FR_N_HASVR == fr) continue; \
			else ir = IR_N; \
			if(ir != IR_O_SBOOIX) return ir; \
		} \
		return ir; \
	}while(0)

/*
*
* Name: _SBO_OBJECT_OUTPUT
* Desc: the _SBO_O_IX of "Output" interface.
*/
#define  _SBO_OBJECT_OUTPUT \
	do{ \
		IRESULT  ir = IR_O__SBOOIX; \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			if(FR_P == CallerCome(*(This->ppo_AIB+i), pCaller)) \
				ir = (*(This->ppo_AIB+i))->Output(*(This->ppo_AIB+i), OStrm, Cty, pQty, pCaller); \
		} \
		return ir; \
	}while(0)

/*
*
* Name: OBS_OBJECT_IOPUT
* Desc: the OBS_O_IX of "IOput" interface.
*/
#define  OBS_OBJECT_IOPUT \
	do{ \
		IRESULT  ir = IR_O_OBSOIX; \
		IRESULT  fr; \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			fr = CallerCome(*(This->ppo_AIB+i), pCaller); \
			if(FR_P == fr) ir = (*(This->ppo_AIB+i))->IOput(*(This->ppo_AIB+i), IStrm, Qty, OStrm, Cty, pQty, pCaller); \
			else if(FR_N_HASVR == fr) continue; \
			else ir = IR_N; \
			if(ir != IR_O_OBSOIX) return ir; \
		} \
	}while(0)

/*
*
* Name: OBS_OBJECT_IOPUT_
* Desc: the OBS_O_IX_ of "IOput" interface.
*/
#define  OBS_OBJECT_IOPUT_ \
	do{ \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			if(FR_P == CallerCome(*(This->ppo_AIB+i), pCaller)) \
				(*(This->ppo_AIB+i))->IOput(*(This->ppo_AIB+i), IStrm, Qty, OStrm, Cty, pQty, pCaller); \
		} \
	}while(0)

/*
*
* Name: SBO_OBJECT_IOPUT
* Desc: the SBO_O_IX of "IOput" interface.
*/
#define  SBO_OBJECT_IOPUT \
	do{ \
		IRESULT  ir = IR_O_SBOOIX; \
		IRESULT  fr; \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			fr = CallerCome(*(This->ppo_AIB+i), pCaller); \
			if(FR_P == fr) ir = (*(This->ppo_AIB+i))->IOput(*(This->ppo_AIB+i), IStrm, Qty, OStrm, Cty, pQty, pCaller); \
			else if(FR_N_HASVR == fr) continue; \
			else ir = IR_N; \
			if(ir != IR_O_SBOOIX) return ir; \
		} \
		return ir; \
	}while(0)

/*
*
* Name: _SBO_OBJECT_IOPUT
* Desc: the _SBO_O_IX of "IOput" interface.
*/
#define  _SBO_OBJECT_IOPUT \
	do{ \
		IRESULT  ir = IR_O__SBOOIX; \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			if(FR_P == CallerCome(*(This->ppo_AIB+i), pCaller)) \
				ir = (*(This->ppo_AIB+i))->IOput(*(This->ppo_AIB+i), IStrm, Qty, OStrm, Cty, pQty, pCaller); \
		} \
		return ir; \
	}while(0)
	
/*
*
* Name: OBS_OBJECT_INTERACT0
* Desc: the OBS_O_IX of "Interact0" interface.
*/
#define  OBS_OBJECT_INTERACT0 \
	do{ \
		IRESULT  ir = IR_O_OBSOIX; \
		IRESULT  fr; \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			fr = CallerCome(*(This->ppo_AIB+i), pCaller); \
			if(FR_P == fr) ir = (*(This->ppo_AIB+i))->Interact0(*(This->ppo_AIB+i), Act, pCaller); \
			else if(FR_N_HASVR == fr) continue; \
			else ir = IR_N; \
			if(ir != IR_O_OBSOIX) return ir; \
		} \
	}while(0)

/*
*
* Name: OBS_OBJECT_INTERACT0_
* Desc: the OBS_O_IX_ of "Interact0" interface.
*/
#define  OBS_OBJECT_INTERACT0_ \
	do{ \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			if(FR_P == CallerCome(*(This->ppo_AIB+i), pCaller)) \
				(*(This->ppo_AIB+i))->Interact0(*(This->ppo_AIB+i), Act, pCaller); \
		} \
	}while(0)

/*
*
* Name: SBO_OBJECT_INTERACT0
* Desc: the SBO_O_IX of "Interact0" interface.
*/
#define  SBO_OBJECT_INTERACT0 \
	do{ \
		IRESULT  ir = IR_O_SBOOIX; \
		IRESULT  fr; \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			fr = CallerCome(*(This->ppo_AIB+i), pCaller); \
			if(FR_P == fr) ir = (*(This->ppo_AIB+i))->Interact0(*(This->ppo_AIB+i), Act, pCaller); \
			else if(FR_N_HASVR == fr) continue; \
			else ir = IR_N; \
			if(ir != IR_O_SBOOIX) return ir; \
		} \
		return ir; \
	}while(0)
	
/*
*
* Name: _SBO_OBJECT_INTERACT0
* Desc: the _SBO_O_IX of "Interact0" interface.
*/
#define  _SBO_OBJECT_INTERACT0 \
	do{ \
		IRESULT  ir = IR_O__SBOOIX; \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			if(FR_P == CallerCome(*(This->ppo_AIB+i), pCaller)) \
				(*(This->ppo_AIB+i))->Interact0(*(This->ppo_AIB+i), Act, pCaller); \
		} \
		return ir; \
	}while(0)

/*
*
* Name: OBS_OBJECT_INTERACT1
* Desc: the OBS_O_IX of "Interact1" interface.
*/
#define  OBS_OBJECT_INTERACT1 \
	do{ \
		IRESULT  ir = IR_O_OBSOIX; \
		IRESULT  fr; \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			fr = CallerCome(*(This->ppo_AIB+i), pCaller); \
			if(FR_P == fr) ir = (*(This->ppo_AIB+i))->Interact1(*(This->ppo_AIB+i), Act, OStrm, Cty, pQty, pCaller); \
			else if(FR_N_HASVR == fr) continue; \
			else ir = IR_N; \
			if(ir != IR_O_OBSOIX) return ir; \
		} \
	}while(0)

/*
*
* Name: OBS_OBJECT_INTERACT1_
* Desc: the OBS_O_IX_ of "Interact1" interface.
*/
#define  OBS_OBJECT_INTERACT1_ \
	do{ \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			if(FR_P == CallerCome(*(This->ppo_AIB+i), pCaller)) \
				(*(This->ppo_AIB+i))->Interact1(*(This->ppo_AIB+i), Act, OStrm, Cty, pQty, pCaller); \
		} \
	}while(0)

/*
*
* Name: SBO_OBJECT_INTERACT1
* Desc: the SBO_O_IX of "Interact1" interface.
*/
#define  SBO_OBJECT_INTERACT1 \
	do{ \
		IRESULT  ir = IR_O_SBOOIX; \
		IRESULT  fr; \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			fr = CallerCome(*(This->ppo_AIB+i), pCaller); \
			if(FR_P == fr) ir = (*(This->ppo_AIB+i))->Interact1(*(This->ppo_AIB+i), Act, OStrm, Cty, pQty, pCaller); \
			else if(FR_N_HASVR == fr) continue; \
			else ir = IR_N; \
			if(ir != IR_O_SBOOIX) return ir; \
		} \
		return ir; \
	}while(0)

/*
*
* Name: _SBO_OBJECT_INTERACT1
* Desc: the _SBO_O_IX of "Interact1" interface.
*/
#define  _SBO_OBJECT_INTERACT1 \
	do{ \
		IRESULT  ir = IR_O__SBOOIX; \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			if(FR_P == CallerCome(*(This->ppo_AIB+i), pCaller)) \
				ir = (*(This->ppo_AIB+i))->Interact1(*(This->ppo_AIB+i), Act, OStrm, Cty, pQty, pCaller); \
		} \
		return ir; \
	}while(0)
	
/*
*
* Name: OBS_OBJECT_INTERACT2
* Desc: the OBS_O_IX of "Interact2" interface.
*/
#define  OBS_OBJECT_INTERACT2 \
	do{ \
		IRESULT  ir = IR_O_OBSOIX; \
		IRESULT  fr; \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			fr = CallerCome(*(This->ppo_AIB+i), pCaller); \
			if(FR_P == fr) ir = (*(This->ppo_AIB+i))->Interact2(*(This->ppo_AIB+i), Act, IStrm, Qty, pCaller); \
			else if(FR_N_HASVR == fr) continue; \
			else ir = IR_N; \
			if(ir != IR_O_OBSOIX) return ir; \
		} \
	}while(0)

/*
*
* Name: OBS_OBJECT_INTERACT2_
* Desc: the OBS_O_IX_ of "Interact2" interface.
*/
#define  OBS_OBJECT_INTERACT2_ \
	do{ \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			if(FR_P == CallerCome(*(This->ppo_AIB+i), pCaller)) \
				(*(This->ppo_AIB+i))->Interact2(*(This->ppo_AIB+i), Act, IStrm, Qty, pCaller); \
		} \
	}while(0)

/*
*
* Name: SBO_OBJECT_INTERACT2
* Desc: the SBO_O_IX of "Interact2" interface.
*/
#define  SBO_OBJECT_INTERACT2 \
	do{ \
		IRESULT  ir = IR_O_SBOOIX; \
		IRESULT  fr; \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			fr = CallerCome(*(This->ppo_AIB+i), pCaller); \
			if(FR_P == fr) ir = (*(This->ppo_AIB+i))->Interact2(*(This->ppo_AIB+i), Act, IStrm, Qty, pCaller); \
			else if(FR_N_HASVR == fr) continue; \
			else ir = IR_N; \
			if(ir != IR_O_SBOOIX) return ir; \
		} \
		return ir; \
	}while(0)

/*
*
* Name: _SBO_OBJECT_INTERACT2
* Desc: the _SBO_O_IX of "Interact2" interface.
*/
#define  _SBO_OBJECT_INTERACT2 \
	do{ \
		IRESULT  ir = IR_O__SBOOIX; \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			if(FR_P == CallerCome(*(This->ppo_AIB+i), pCaller)) \
				ir = (*(This->ppo_AIB+i))->Interact2(*(This->ppo_AIB+i), Act, IStrm, Qty, pCaller); \
		} \
		return ir; \
	}while(0)
	
/*
*
* Name: OBS_OBJECT_INTERACT3
* Desc: the OBS_O_IX of "Interact3" interface.
*/
#define  OBS_OBJECT_INTERACT3 \
	do{ \
		IRESULT  ir = IR_O_OBSOIX; \
		IRESULT  fr; \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			fr = CallerCome(*(This->ppo_AIB+i), pCaller); \
			if(FR_P == fr) ir = (*(This->ppo_AIB+i))->Interact3(*(This->ppo_AIB+i), Act, IStrm, Qty, OStrm, Cty, pQty, pCaller); \
			else if(FR_N_HASVR == fr) continue; \
			else ir = IR_N; \
			if(ir != IR_O_OBSOIX) return ir; \
		} \
	}while(0)

/*
*
* Name: OBS_OBJECT_INTERACT3_
* Desc: the OBS_O_IX_ of "Interact3" interface.
*/
#define  OBS_OBJECT_INTERACT3_ \
	do{ \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			if(FR_P == CallerCome(*(This->ppo_AIB+i), pCaller)) \
				(*(This->ppo_AIB+i))->Interact3(*(This->ppo_AIB+i), Act, IStrm, Qty, OStrm, Cty, pQty, pCaller); \
		} \
	}while(0)
 
/*
*
* Name: SBO_OBJECT_INTERACT3
* Desc: the SBO_O_IX of "Interact3" interface.
*/
#define  SBO_OBJECT_INTERACT3 \
	do{ \
		IRESULT  ir = IR_O_SBOOIX; \
		IRESULT  fr; \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			fr = CallerCome(*(This->ppo_AIB+i), pCaller); \
			if(FR_P == fr) ir = (*(This->ppo_AIB+i))->Interact3(*(This->ppo_AIB+i), Act, IStrm, Qty, OStrm, Cty, pQty, pCaller); \
			else if(FR_N_HASVR == fr) continue; \
			else ir = IR_N; \
			if(ir != IR_O_SBOOIX) return ir; \
		} \
		return ir; \
	}while(0)

/*
*
* Name: _SBO_OBJECT_INTERACT3
* Desc: the _SBO_O_IX of "Interact3" interface.
*/
#define  _SBO_OBJECT_INTERACT3 \
	do{ \
		IRESULT  ir = IR_O__SBOOIX; \
		IRESULT  fr; \
		NUMIB    i; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			if(FR_P == CallerCome(*(This->ppo_AIB+i), pCaller)) \
				ir = (*(This->ppo_AIB+i))->Interact3(*(This->ppo_AIB+i), Act, IStrm, Qty, OStrm, Cty, pQty, pCaller); \
		} \
		return ir; \
	}while(0)

/*
*
* Name: OBS_OBJECT_CLOSE_
* Desc: the OBS_O_IX_ of "Close" interface.
*/
#define  OBS_OBJECT_CLOSE_ \
	do{ \
		IRESULT  ir; \
		IRESULT  fr; \
		NUMIB    i; \
		if( 0 == This->RefCnt ) \
			return IR_O_NOPEN; \
		This->RefCnt--; \
		for(i=0; i<This->NIB; i++) \
		{ \
			extern  FRESULT CallerCome(OBJECT* pND, const VR* pCaller); \
			if((*(This->ppo_AIB+i))->RefCnt -1 == This->RefCnt) \
			{ \
				fr = CallerCome(*(This->ppo_AIB+i), pCaller); \
				if(FR_P == fr) ir = (*(This->ppo_AIB+i))->Close(*(This->ppo_AIB+i), pCaller); \
				else if(FR_N_HASVR == fr) continue; \
				else ir = IR_N; \
				if( NIR(ir) ) \
				{ \
					This->RefCnt++; \
					return ir; \
				} \
			} \
		} \
	}while(0)

/*==========+  CreateObject & DestroyObject  +===========*/

/*
*
* Name: CreateObject
* Desc: Dynamically creates an object.
* Para: Msn --- [IN] the Mold Serial Number, specifies to create which mold object;
*       IQCty --- [IN] the capacity of input queue;
*       OQCty --- [IN] the capacity of output queue;
*       NumCR --- [IN] the number of caller;
*       ppObj --- [OUT] the created object.
*/
extern  FRESULT  __CreateObject__(MLDSN Msn, BYTKTY IQCty, BYTKTY OQCty, SI32 NumCR, OBJECT** ppObj, BYTE* pExotic);
#define  CreateObject(Msn, IQCty, OQCty, NumCR, ppObj) \
	    __CreateObject__(Msn, IQCty, OQCty, NumCR, ppObj, NULL)

/*
*
* Name: DestroyObject
* Desc: Destroys an object created dynamically by the "CreateObject" macro.
* Para: pObj --- [IN] points the object.
*/
extern  BOOL  __DestroyObject__(OBJECT*  pObj); 
#define  DestroyObject( pObj ) \
	do{ \
		if(TRUE == __DestroyObject__(pObj)) \
		{ \
			free(pObj); \
			(pObj) = NULL; \
		} \
	}while(0) 

/*=+ Externally declare the functions called directly by outside +=*/

extern  FRESULT  Enqueue(QUEUE* pq, BYTE* IData, BYTKTY Qty);
extern  FRESULT  Dequeue(QUEUE* pq, BYTE* OData, BYTKTY Cty, BYTKTY* pQty);
extern  OBJECT*  GetBN(OBJECT* pND, MLDSN msn);
extern  EM*      GetEMofBN(OBJECT* pND, MLDSN msn);
extern  QUEUE*   GetIQ(OBJECT* pND);
extern  QUEUE*   GetOQ(OBJECT* pND);

#if INLINE_VOFUNCTION == 0

extern  IRESULT VO_Open(OBJECT* pObject, const VR* pCaller);
extern  IRESULT VO_Input(OBJECT* pObject, BYTE* IStrm, BYTKTY Qty, const VR* pCaller);
extern  IRESULT VO_Output(OBJECT* pObject, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller); 
extern  IRESULT VO_IOput(OBJECT* pObject, BYTE* IStrm, BYTKTY Qty, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller);
extern  IRESULT VO_Interact0(OBJECT* pObject, ACTION Act, const VR* pCaller); 
extern  IRESULT VO_Interact1(OBJECT* pObject, ACTION Act, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller);
extern  IRESULT VO_Interact2(OBJECT* pObject, ACTION Act, BYTE* IStrm, BYTKTY Qty, const VR* pCaller);
extern  IRESULT VO_Interact3(OBJECT* pObject, ACTION Act, BYTE* IStrm, BYTKTY Qty, BYTE* OStrm, BYTKTY Cty, BYTKTY* pQty, const VR* pCaller);
extern  IRESULT VO_Close(OBJECT* pObject, const VR* pCaller);

#endif


#endif  /* #ifndef __OIOIC_H__ */
